# Proforma CRM

A multi-user CRM for quoting, lead tracking, and project delivery — built on React + Vite + TypeScript, backed by Supabase (Postgres + Auth).

## Features

- **Leads Pipeline** — Kanban board (New → Contacted → Qualified → Quoted → Won → Lost)
- **Clients** — a shared contact/account record that leads, proformas, and projects all link back to
- **Proformas** — quote builder with line items, tax, discounts, PDF export, mailto sharing
- **Projects** — post-acceptance delivery tracking: expenses, work logs, invoices
- **Tasks & Reminders** — overdue/due-today/upcoming follow-ups, linkable to any record
- **Reports** — pipeline funnel, win rate, weighted revenue forecast, collected-revenue trend
- **Multi-user with roles** — Owner / Sales / Finance / Viewer, enforced by database-level security (not just hidden buttons)

## Setup

**Prerequisites:** Node.js 18+, a free [Supabase](https://supabase.com) account.

1. **Install dependencies**
   ```
   npm install
   ```

2. **Create a Supabase project**, then open its SQL Editor and run the contents of [`supabase/schema.sql`](supabase/schema.sql). This creates every table, security policy, and the trigger that auto-creates a profile for each new signup.

3. **Copy your API credentials** from Project Settings → API, and create `.env.local` in the project root:
   ```
   VITE_SUPABASE_URL=https://your-project-ref.supabase.co
   VITE_SUPABASE_ANON_KEY=your-anon-public-key
   ```

4. **Run the app**
   ```
   npm run dev
   ```

5. **Sign up** inside the app. The first account created on a fresh workspace automatically becomes the **Owner** — promote teammates to other roles from Settings → Team once they've signed up.

If `.env.local` isn't set, the app shows an in-app setup screen with these same steps instead of crashing.

## Roles

| Role | Can manage |
|---|---|
| Owner | Everything, including Settings and Team |
| Sales | Clients, Leads, Proformas |
| Finance | Projects, Expenses, Invoices |
| Viewer | Read-only everywhere |

Enforced both in the UI and via Postgres Row Level Security, so it holds even if someone calls the API directly.
