-- =========================================================================
-- Proforma Hub CRM — Supabase schema
-- Run this once in your Supabase project's SQL Editor (Project > SQL Editor > New Query).
-- Safe to re-run: uses IF NOT EXISTS / CREATE OR REPLACE throughout.
-- =========================================================================

-- ---------------------------------------------------------------------
-- 1. PROFILES  (one row per authenticated user; role drives permissions)
-- ---------------------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text not null default '',
  role text not null default 'viewer' check (role in ('owner','sales','finance','viewer')),
  created_at timestamptz not null default now()
);

-- Auto-create a profile row whenever someone signs up.
-- The very first person to ever sign up becomes 'owner'; everyone after defaults to 'viewer'
-- (the owner can promote teammates later from the Team screen).
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name, email, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', new.email),
    new.email,
    case when (select count(*) from public.profiles) = 0 then 'owner' else 'viewer' end
  );
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ---------------------------------------------------------------------
-- 2. COMPANY SETTINGS  (single shared row for the whole workspace)
-- ---------------------------------------------------------------------
create table if not exists public.company_settings (
  id int primary key default 1,
  company_name text not null default 'My Company',
  address text not null default '',
  email text not null default '',
  phone text not null default '',
  logo_url text not null default '',
  header_image_url text not null default '',
  footer_image1_url text not null default '',
  footer_image2_url text not null default '',
  stamp_image_url text not null default '',
  tax_rate numeric not null default 0,
  currency text not null default 'USD',
  payment_terms text not null default '',
  payment_terms_list jsonb not null default '[]',
  validity_days text not null default '30',
  delivery_terms text not null default '',
  updated_at timestamptz not null default now(),
  constraint single_row check (id = 1)
);
insert into public.company_settings (id) values (1) on conflict (id) do nothing;

-- ---------------------------------------------------------------------
-- 3. CLIENTS  (the Contact/Account entity — everything else links here)
-- ---------------------------------------------------------------------
create table if not exists public.clients (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  company text not null default '',
  email text not null default '',
  phone text not null default '',
  address text not null default '',
  notes text not null default '',
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 4. LEADS + LEAD ACTIVITIES
-- ---------------------------------------------------------------------
create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  client_id uuid references public.clients(id) on delete set null,
  name text not null,
  company text not null default '',
  email text not null default '',
  phone text not null default '',
  address text not null default '',
  source text not null default '',
  estimated_value numeric not null default 0,
  stage text not null default 'New' check (stage in ('New','Contacted','Qualified','Quoted','Won','Lost')),
  proforma_id uuid,
  lost_reason text not null default '',
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.lead_activities (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references public.leads(id) on delete cascade,
  note text not null,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 5. PROFORMAS
-- ---------------------------------------------------------------------
create table if not exists public.proformas (
  id uuid primary key default gen_random_uuid(),
  client_id uuid references public.clients(id) on delete set null,
  proforma_number text not null,
  issue_date date not null default current_date,
  expiry_date date,
  client_name text not null default '',
  client_email text not null default '',
  client_phone text not null default '',
  client_address text not null default '',
  items jsonb not null default '[]',
  discount_type text not null default 'percentage',
  discount_value numeric not null default 0,
  status text not null default 'Draft' check (status in ('Draft','Sent','Accepted','Rejected','Converted')),
  subtotal numeric not null default 0,
  tax_total numeric not null default 0,
  discount_total numeric not null default 0,
  grand_total numeric not null default 0,
  include_stamp boolean not null default false,
  payment_terms_list jsonb not null default '[]',
  validity_days text not null default '30',
  delivery_terms text not null default '',
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 6. PROJECTS, EXPENSES, PROJECT LOGS, INVOICES
-- ---------------------------------------------------------------------
create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  proforma_id uuid references public.proformas(id) on delete set null,
  client_id uuid references public.clients(id) on delete set null,
  client_name text not null default '',
  work_order_number text not null default '',
  assigned_team text not null default '',
  start_date date,
  target_date date,
  status text not null default 'In Progress' check (status in ('In Progress','On Hold','Completed','Closed')),
  contract_value numeric not null default 0,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  category text not null default 'Misc' check (category in ('Materials','Labor','Transport','Misc')),
  amount numeric not null default 0,
  description text not null default '',
  receipt_number text not null default '',
  date date not null default current_date,
  created_by uuid references public.profiles(id)
);

create table if not exists public.project_logs (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  note text not null,
  date timestamptz not null default now(),
  created_by uuid references public.profiles(id)
);

create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  type text not null default 'Payment Request' check (type in ('Payment Request','Final Invoice')),
  invoice_number text not null default '',
  amount numeric not null default 0,
  status text not null default 'Pending' check (status in ('Pending','Paid')),
  date date not null default current_date,
  notes text not null default '',
  created_by uuid references public.profiles(id)
);

-- ---------------------------------------------------------------------
-- 7. TASKS  (reminders/follow-ups, linkable to any other record)
-- ---------------------------------------------------------------------
create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  notes text not null default '',
  related_type text check (related_type in ('lead','client','project','proforma','invoice',null)),
  related_id uuid,
  due_date date,
  completed boolean not null default false,
  assigned_to uuid references public.profiles(id),
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

-- =========================================================================
-- ROW LEVEL SECURITY
-- Model: every authenticated teammate can READ everything (shared workspace).
-- WRITE access is role-gated:
--   owner   -> full access everywhere, incl. settings & team management
--   sales   -> manage clients/leads/proformas, read-only elsewhere
--   finance -> manage projects/expenses/invoices, read-only elsewhere
--   viewer  -> read-only everywhere
-- =========================================================================

create or replace function public.current_role_name()
returns text as $$
  select role from public.profiles where id = auth.uid();
$$ language sql stable security definer;

-- PROFILES: everyone can read all profiles (for the Team screen); only the
-- owner can change roles; a user can update their own full_name.
alter table public.profiles enable row level security;
drop policy if exists "profiles_select_all" on public.profiles;
create policy "profiles_select_all" on public.profiles for select using (auth.uid() is not null);
drop policy if exists "profiles_update_self_or_owner" on public.profiles;
create policy "profiles_update_self_or_owner" on public.profiles for update
  using (auth.uid() = id or public.current_role_name() = 'owner');

-- COMPANY SETTINGS: everyone reads; only owner writes.
alter table public.company_settings enable row level security;
drop policy if exists "settings_select_all" on public.company_settings;
create policy "settings_select_all" on public.company_settings for select using (auth.uid() is not null);
drop policy if exists "settings_update_owner" on public.company_settings;
create policy "settings_update_owner" on public.company_settings for update using (public.current_role_name() = 'owner');

-- Generic helper macro pattern applied per table below:
-- select: any authenticated user
-- insert/update/delete: owner, or the role that "owns" that domain

-- CLIENTS (owner + sales)
alter table public.clients enable row level security;
drop policy if exists "clients_select" on public.clients;
create policy "clients_select" on public.clients for select using (auth.uid() is not null);
drop policy if exists "clients_write" on public.clients;
create policy "clients_write" on public.clients for all
  using (public.current_role_name() in ('owner','sales'))
  with check (public.current_role_name() in ('owner','sales'));

-- LEADS + ACTIVITIES (owner + sales)
alter table public.leads enable row level security;
drop policy if exists "leads_select" on public.leads;
create policy "leads_select" on public.leads for select using (auth.uid() is not null);
drop policy if exists "leads_write" on public.leads;
create policy "leads_write" on public.leads for all
  using (public.current_role_name() in ('owner','sales'))
  with check (public.current_role_name() in ('owner','sales'));

alter table public.lead_activities enable row level security;
drop policy if exists "lead_activities_select" on public.lead_activities;
create policy "lead_activities_select" on public.lead_activities for select using (auth.uid() is not null);
drop policy if exists "lead_activities_write" on public.lead_activities;
create policy "lead_activities_write" on public.lead_activities for all
  using (public.current_role_name() in ('owner','sales'))
  with check (public.current_role_name() in ('owner','sales'));

-- PROFORMAS (owner + sales)
alter table public.proformas enable row level security;
drop policy if exists "proformas_select" on public.proformas;
create policy "proformas_select" on public.proformas for select using (auth.uid() is not null);
drop policy if exists "proformas_write" on public.proformas;
create policy "proformas_write" on public.proformas for all
  using (public.current_role_name() in ('owner','sales'))
  with check (public.current_role_name() in ('owner','sales'));

-- PROJECTS (owner + sales create/convert; finance can update status/value too)
alter table public.projects enable row level security;
drop policy if exists "projects_select" on public.projects;
create policy "projects_select" on public.projects for select using (auth.uid() is not null);
drop policy if exists "projects_write" on public.projects;
create policy "projects_write" on public.projects for all
  using (public.current_role_name() in ('owner','sales','finance'))
  with check (public.current_role_name() in ('owner','sales','finance'));

-- EXPENSES, PROJECT LOGS, INVOICES (owner + finance)
alter table public.expenses enable row level security;
drop policy if exists "expenses_select" on public.expenses;
create policy "expenses_select" on public.expenses for select using (auth.uid() is not null);
drop policy if exists "expenses_write" on public.expenses;
create policy "expenses_write" on public.expenses for all
  using (public.current_role_name() in ('owner','finance'))
  with check (public.current_role_name() in ('owner','finance'));

alter table public.project_logs enable row level security;
drop policy if exists "project_logs_select" on public.project_logs;
create policy "project_logs_select" on public.project_logs for select using (auth.uid() is not null);
drop policy if exists "project_logs_write" on public.project_logs;
create policy "project_logs_write" on public.project_logs for all
  using (public.current_role_name() in ('owner','sales','finance'))
  with check (public.current_role_name() in ('owner','sales','finance'));

alter table public.invoices enable row level security;
drop policy if exists "invoices_select" on public.invoices;
create policy "invoices_select" on public.invoices for select using (auth.uid() is not null);
drop policy if exists "invoices_write" on public.invoices;
create policy "invoices_write" on public.invoices for all
  using (public.current_role_name() in ('owner','finance'))
  with check (public.current_role_name() in ('owner','finance'));

-- TASKS (any authenticated user can manage tasks — viewer excluded from writes)
alter table public.tasks enable row level security;
drop policy if exists "tasks_select" on public.tasks;
create policy "tasks_select" on public.tasks for select using (auth.uid() is not null);
drop policy if exists "tasks_write" on public.tasks;
create policy "tasks_write" on public.tasks for all
  using (public.current_role_name() <> 'viewer')
  with check (public.current_role_name() <> 'viewer');

-- =========================================================================
-- Done. Next steps in the app:
--   1. Project Settings > API — copy your Project URL and anon public key.
--   2. Put them in .env.local as VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY.
--   3. Sign up inside the app — the first account becomes the 'owner'.
-- =========================================================================
