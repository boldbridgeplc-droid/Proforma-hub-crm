import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '../lib/supabase';
import {
  Client, Lead, LeadActivity, Proforma, Project, Expense, ProjectLog, Invoice, Task,
  CompanySettings, Profile
} from '../types';

// ---------------------------------------------------------------------
// Row <-> App-type mappers (DB is snake_case, app is camelCase)
// ---------------------------------------------------------------------

const toClient = (r: any): Client => ({
  id: r.id, name: r.name, company: r.company, email: r.email, phone: r.phone,
  address: r.address, notes: r.notes, createdAt: r.created_at, updatedAt: r.updated_at,
});
const fromClient = (c: Partial<Client>) => ({
  id: c.id, name: c.name, company: c.company, email: c.email, phone: c.phone,
  address: c.address, notes: c.notes,
});

const toLead = (r: any): Lead => ({
  id: r.id, clientId: r.client_id, name: r.name, company: r.company, email: r.email,
  phone: r.phone, address: r.address, source: r.source, estimatedValue: Number(r.estimated_value) || 0,
  stage: r.stage, createdAt: r.created_at, updatedAt: r.updated_at, proformaId: r.proforma_id,
  lostReason: r.lost_reason,
});
const fromLead = (l: Partial<Lead>) => ({
  id: l.id, client_id: l.clientId ?? null, name: l.name, company: l.company, email: l.email,
  phone: l.phone, address: l.address, source: l.source, estimated_value: l.estimatedValue,
  stage: l.stage, proforma_id: l.proformaId ?? null, lost_reason: l.lostReason,
});

const toLeadActivity = (r: any): LeadActivity => ({ id: r.id, leadId: r.lead_id, note: r.note, date: r.created_at });

const toProforma = (r: any): Proforma => ({
  id: r.id, clientId: r.client_id, proformaNumber: r.proforma_number, issueDate: r.issue_date,
  expiryDate: r.expiry_date, clientName: r.client_name, clientEmail: r.client_email,
  clientPhone: r.client_phone, clientAddress: r.client_address, items: r.items || [],
  discountType: r.discount_type, discountValue: Number(r.discount_value) || 0, status: r.status,
  subtotal: Number(r.subtotal) || 0, taxTotal: Number(r.tax_total) || 0,
  discountTotal: Number(r.discount_total) || 0, grandTotal: Number(r.grand_total) || 0,
  includeStamp: r.include_stamp, paymentTermsList: r.payment_terms_list || [],
  validityDays: r.validity_days, deliveryTerms: r.delivery_terms,
});
const fromProforma = (p: Proforma) => ({
  id: p.id, client_id: p.clientId ?? null, proforma_number: p.proformaNumber, issue_date: p.issueDate,
  expiry_date: p.expiryDate, client_name: p.clientName, client_email: p.clientEmail,
  client_phone: p.clientPhone, client_address: p.clientAddress, items: p.items,
  discount_type: p.discountType, discount_value: p.discountValue, status: p.status,
  subtotal: p.subtotal, tax_total: p.taxTotal, discount_total: p.discountTotal,
  grand_total: p.grandTotal, include_stamp: p.includeStamp, payment_terms_list: p.paymentTermsList,
  validity_days: p.validityDays, delivery_terms: p.deliveryTerms,
});

const toProject = (r: any): Project => ({
  id: r.id, proformaId: r.proforma_id, clientId: r.client_id, clientName: r.client_name,
  workOrderNumber: r.work_order_number, assignedTeam: r.assigned_team, startDate: r.start_date,
  targetDate: r.target_date, status: r.status, contractValue: Number(r.contract_value) || 0,
  createdAt: r.created_at,
});
const fromProject = (p: Partial<Project>) => ({
  id: p.id, proforma_id: p.proformaId, client_id: p.clientId ?? null, client_name: p.clientName,
  work_order_number: p.workOrderNumber, assigned_team: p.assignedTeam, start_date: p.startDate,
  target_date: p.targetDate, status: p.status, contract_value: p.contractValue,
});

const toExpense = (r: any): Expense => ({
  id: r.id, projectId: r.project_id, category: r.category, amount: Number(r.amount) || 0,
  description: r.description, receiptNumber: r.receipt_number, date: r.date,
});
const fromExpense = (e: Expense) => ({
  id: e.id, project_id: e.projectId, category: e.category, amount: e.amount,
  description: e.description, receipt_number: e.receiptNumber, date: e.date,
});

const toLog = (r: any): ProjectLog => ({ id: r.id, projectId: r.project_id, note: r.note, date: r.date });
const fromLog = (l: ProjectLog) => ({ id: l.id, project_id: l.projectId, note: l.note, date: l.date });

const toInvoice = (r: any): Invoice => ({
  id: r.id, projectId: r.project_id, type: r.type, invoiceNumber: r.invoice_number,
  amount: Number(r.amount) || 0, status: r.status, date: r.date, notes: r.notes,
});
const fromInvoice = (i: Partial<Invoice>) => ({
  id: i.id, project_id: i.projectId, type: i.type, invoice_number: i.invoiceNumber,
  amount: i.amount, status: i.status, date: i.date, notes: i.notes,
});

const toTask = (r: any): Task => ({
  id: r.id, title: r.title, notes: r.notes, relatedType: r.related_type, relatedId: r.related_id,
  dueDate: r.due_date, completed: r.completed, assignedTo: r.assigned_to, createdBy: r.created_by,
  createdAt: r.created_at,
});
const fromTask = (t: Partial<Task>) => ({
  id: t.id, title: t.title, notes: t.notes, related_type: t.relatedType ?? null,
  related_id: t.relatedId ?? null, due_date: t.dueDate ?? null, completed: t.completed,
  assigned_to: t.assignedTo ?? null,
});

const toSettings = (r: any): CompanySettings => ({
  companyName: r.company_name, address: r.address, email: r.email, phone: r.phone,
  logoUrl: r.logo_url, headerImageUrl: r.header_image_url, footerImage1Url: r.footer_image1_url,
  footerImage2Url: r.footer_image2_url, stampImageUrl: r.stamp_image_url, taxRate: Number(r.tax_rate) || 0,
  currency: r.currency, paymentTerms: r.payment_terms, paymentTermsList: r.payment_terms_list || [],
  validityDays: r.validity_days, deliveryTerms: r.delivery_terms,
});
const fromSettings = (s: CompanySettings) => ({
  company_name: s.companyName, address: s.address, email: s.email, phone: s.phone,
  logo_url: s.logoUrl, header_image_url: s.headerImageUrl, footer_image1_url: s.footerImage1Url,
  footer_image2_url: s.footerImage2Url, stamp_image_url: s.stampImageUrl, tax_rate: s.taxRate,
  currency: s.currency, payment_terms: s.paymentTerms, payment_terms_list: s.paymentTermsList,
  validity_days: s.validityDays, delivery_terms: s.deliveryTerms,
});

const toProfile = (r: any): Profile => ({ id: r.id, fullName: r.full_name, email: r.email, role: r.role, createdAt: r.created_at });

const DEFAULT_SETTINGS: CompanySettings = {
  companyName: 'My Company', address: '', email: '', phone: '', logoUrl: '', taxRate: 0,
  currency: 'USD', paymentTerms: '', paymentTermsList: [], validityDays: '30', deliveryTerms: '',
};

export function useSupabaseCRM(ready: boolean) {
  const [loading, setLoading] = useState(true);
  const [clients, setClients] = useState<Client[]>([]);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [leadActivities, setLeadActivities] = useState<LeadActivity[]>([]);
  const [proformas, setProformas] = useState<Proforma[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [projectLogs, setProjectLogs] = useState<ProjectLog[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [settings, setSettings] = useState<CompanySettings>(DEFAULT_SETTINGS);
  const [team, setTeam] = useState<Profile[]>([]);
  const mounted = useRef(true);

  const fetchAll = useCallback(async () => {
    const [c, l, la, p, pr, ex, pl, inv, tk, st, tm] = await Promise.all([
      supabase.from('clients').select('*').order('created_at', { ascending: false }),
      supabase.from('leads').select('*').order('created_at', { ascending: false }),
      supabase.from('lead_activities').select('*').order('created_at', { ascending: false }),
      supabase.from('proformas').select('*').order('created_at', { ascending: false }),
      supabase.from('projects').select('*').order('created_at', { ascending: false }),
      supabase.from('expenses').select('*').order('date', { ascending: false }),
      supabase.from('project_logs').select('*').order('date', { ascending: false }),
      supabase.from('invoices').select('*').order('date', { ascending: false }),
      supabase.from('tasks').select('*').order('due_date', { ascending: true }),
      supabase.from('company_settings').select('*').eq('id', 1).single(),
      supabase.from('profiles').select('*').order('created_at', { ascending: true }),
    ]);
    if (!mounted.current) return;
    if (c.data) setClients(c.data.map(toClient));
    if (l.data) setLeads(l.data.map(toLead));
    if (la.data) setLeadActivities(la.data.map(toLeadActivity));
    if (p.data) setProformas(p.data.map(toProforma));
    if (pr.data) setProjects(pr.data.map(toProject));
    if (ex.data) setExpenses(ex.data.map(toExpense));
    if (pl.data) setProjectLogs(pl.data.map(toLog));
    if (inv.data) setInvoices(inv.data.map(toInvoice));
    if (tk.data) setTasks(tk.data.map(toTask));
    if (st.data) setSettings(toSettings(st.data));
    if (tm.data) setTeam(tm.data.map(toProfile));
    setLoading(false);
  }, []);

  useEffect(() => {
    mounted.current = true;
    if (!ready) return;
    fetchAll();

    // Realtime: refetch the relevant slice whenever any teammate changes a table.
    const tables: [string, (rows: any[]) => void, (t: string) => PromiseLike<{ data: any[] | null }>][] = [
      ['clients', (d) => setClients(d.map(toClient)), (t) => supabase.from(t).select('*').order('created_at', { ascending: false })],
      ['leads', (d) => setLeads(d.map(toLead)), (t) => supabase.from(t).select('*').order('created_at', { ascending: false })],
      ['lead_activities', (d) => setLeadActivities(d.map(toLeadActivity)), (t) => supabase.from(t).select('*').order('created_at', { ascending: false })],
      ['proformas', (d) => setProformas(d.map(toProforma)), (t) => supabase.from(t).select('*').order('created_at', { ascending: false })],
      ['projects', (d) => setProjects(d.map(toProject)), (t) => supabase.from(t).select('*').order('created_at', { ascending: false })],
      ['expenses', (d) => setExpenses(d.map(toExpense)), (t) => supabase.from(t).select('*').order('date', { ascending: false })],
      ['project_logs', (d) => setProjectLogs(d.map(toLog)), (t) => supabase.from(t).select('*').order('date', { ascending: false })],
      ['invoices', (d) => setInvoices(d.map(toInvoice)), (t) => supabase.from(t).select('*').order('date', { ascending: false })],
      ['tasks', (d) => setTasks(d.map(toTask)), (t) => supabase.from(t).select('*').order('due_date', { ascending: true })],
      ['profiles', (d) => setTeam(d.map(toProfile)), (t) => supabase.from(t).select('*').order('created_at', { ascending: true })],
    ];

    const channel = supabase.channel('crm-realtime');
    tables.forEach(([table, setter, refetch]) => {
      channel.on('postgres_changes', { event: '*', schema: 'public', table }, async () => {
        const { data } = await refetch(table);
        if (data && mounted.current) setter(data);
      });
    });
    channel.on('postgres_changes', { event: '*', schema: 'public', table: 'company_settings' }, async () => {
      const { data } = await supabase.from('company_settings').select('*').eq('id', 1).single();
      if (data && mounted.current) setSettings(toSettings(data));
    });
    channel.subscribe();

    return () => {
      mounted.current = false;
      supabase.removeChannel(channel);
    };
  }, [ready, fetchAll]);

  // ---- Clients ----
  const addClient = async (c: Client) => {
    const { data } = await supabase.from('clients').insert(fromClient(c)).select().single();
    if (data) setClients(prev => [toClient(data), ...prev]);
  };
  const updateClient = async (id: string, updates: Partial<Client>) => {
    const { data } = await supabase.from('clients').update({ ...fromClient(updates), updated_at: new Date().toISOString() }).eq('id', id).select().single();
    if (data) setClients(prev => prev.map(c => c.id === id ? toClient(data) : c));
  };
  const deleteClient = async (id: string) => {
    await supabase.from('clients').delete().eq('id', id);
    setClients(prev => prev.filter(c => c.id !== id));
  };

  // ---- Leads ----
  const addLead = async (l: Lead) => {
    const { data } = await supabase.from('leads').insert(fromLead(l)).select().single();
    if (data) setLeads(prev => [toLead(data), ...prev]);
  };
  const updateLead = async (id: string, updates: Partial<Lead>) => {
    const { data } = await supabase.from('leads').update({ ...fromLead(updates), updated_at: new Date().toISOString() }).eq('id', id).select().single();
    if (data) setLeads(prev => prev.map(l => l.id === id ? toLead(data) : l));
  };
  const deleteLead = async (id: string) => {
    await supabase.from('leads').delete().eq('id', id);
    setLeads(prev => prev.filter(l => l.id !== id));
    setLeadActivities(prev => prev.filter(a => a.leadId !== id));
  };
  const addLeadActivity = async (a: LeadActivity) => {
    const { data } = await supabase.from('lead_activities').insert({ id: a.id, lead_id: a.leadId, note: a.note }).select().single();
    if (data) setLeadActivities(prev => [toLeadActivity(data), ...prev]);
  };

  // ---- Proformas (upsert-style save, matching CreateProforma's single-record flow) ----
  const saveProforma = async (p: Proforma) => {
    const { data } = await supabase.from('proformas').upsert(fromProforma(p)).select().single();
    if (data) {
      const mapped = toProforma(data);
      setProformas(prev => {
        const exists = prev.some(x => x.id === mapped.id);
        return exists ? prev.map(x => x.id === mapped.id ? mapped : x) : [mapped, ...prev];
      });
      return mapped;
    }
    return p;
  };
  const deleteProforma = async (id: string) => {
    await supabase.from('proformas').delete().eq('id', id);
    setProformas(prev => prev.filter(p => p.id !== id));
  };

  // ---- Projects ----
  const addProject = async (p: Project) => {
    const { data } = await supabase.from('projects').insert(fromProject(p)).select().single();
    if (data) setProjects(prev => [toProject(data), ...prev]);
  };
  const updateProject = async (id: string, updates: Partial<Project>) => {
    const { data } = await supabase.from('projects').update(fromProject(updates)).eq('id', id).select().single();
    if (data) setProjects(prev => prev.map(p => p.id === id ? toProject(data) : p));
  };
  const deleteProject = async (id: string) => {
    await supabase.from('projects').delete().eq('id', id);
    setProjects(prev => prev.filter(p => p.id !== id));
  };

  // ---- Expenses / Logs / Invoices ----
  const addExpense = async (e: Expense) => {
    const { data } = await supabase.from('expenses').insert(fromExpense(e)).select().single();
    if (data) setExpenses(prev => [toExpense(data), ...prev]);
  };
  const deleteExpense = async (id: string) => {
    await supabase.from('expenses').delete().eq('id', id);
    setExpenses(prev => prev.filter(e => e.id !== id));
  };
  const addLog = async (l: ProjectLog) => {
    const { data } = await supabase.from('project_logs').insert(fromLog(l)).select().single();
    if (data) setProjectLogs(prev => [toLog(data), ...prev]);
  };
  const deleteLog = async (id: string) => {
    await supabase.from('project_logs').delete().eq('id', id);
    setProjectLogs(prev => prev.filter(l => l.id !== id));
  };
  const addInvoice = async (i: Invoice) => {
    const { data } = await supabase.from('invoices').insert(fromInvoice(i)).select().single();
    if (data) setInvoices(prev => [toInvoice(data), ...prev]);
  };
  const updateInvoice = async (id: string, updates: Partial<Invoice>) => {
    const { data } = await supabase.from('invoices').update(fromInvoice(updates)).eq('id', id).select().single();
    if (data) setInvoices(prev => prev.map(i => i.id === id ? toInvoice(data) : i));
  };

  // ---- Tasks ----
  const addTask = async (t: Task) => {
    const { data } = await supabase.from('tasks').insert(fromTask(t)).select().single();
    if (data) setTasks(prev => [toTask(data), ...prev]);
  };
  const updateTask = async (id: string, updates: Partial<Task>) => {
    const { data } = await supabase.from('tasks').update(fromTask(updates)).eq('id', id).select().single();
    if (data) setTasks(prev => prev.map(t => t.id === id ? toTask(data) : t));
  };
  const deleteTask = async (id: string) => {
    await supabase.from('tasks').delete().eq('id', id);
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  // ---- Settings ----
  const updateSettings = async (updates: Partial<CompanySettings>) => {
    const merged = { ...settings, ...updates };
    const { data } = await supabase.from('company_settings').update({ ...fromSettings(merged), updated_at: new Date().toISOString() }).eq('id', 1).select().single();
    if (data) setSettings(toSettings(data));
  };

  // ---- Team / roles ----
  const updateTeamRole = async (userId: string, role: Profile['role']) => {
    const { data } = await supabase.from('profiles').update({ role }).eq('id', userId).select().single();
    if (data) setTeam(prev => prev.map(p => p.id === userId ? toProfile(data) : p));
  };

  return {
    loading,
    clients, addClient, updateClient, deleteClient,
    leads, addLead, updateLead, deleteLead,
    leadActivities, addLeadActivity,
    proformas, saveProforma, deleteProforma,
    projects, addProject, updateProject, deleteProject,
    expenses, addExpense, deleteExpense,
    projectLogs, addLog, deleteLog,
    invoices, addInvoice, updateInvoice,
    tasks, addTask, updateTask, deleteTask,
    settings, updateSettings,
    team, updateTeamRole,
  };
}
