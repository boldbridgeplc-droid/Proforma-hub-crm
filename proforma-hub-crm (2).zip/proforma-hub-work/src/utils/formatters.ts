export const formatCurrency = (amount: number, currencyCode: string) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currencyCode || 'USD',
  }).format(amount);
};

export const generateProformaNumber = (existingProformas: any[]) => {
  const prefix = 'PF-';
  if (!existingProformas || existingProformas.length === 0) {
    return `${prefix}0001`;
  }
  
  // Find the highest number
  let maxNum = 0;
  existingProformas.forEach(p => {
    const numPart = p.proformaNumber.replace(prefix, '');
    const num = parseInt(numPart, 10);
    if (!isNaN(num) && num > maxNum) {
      maxNum = num;
    }
  });
  
  return `${prefix}${(maxNum + 1).toString().padStart(4, '0')}`;
};
