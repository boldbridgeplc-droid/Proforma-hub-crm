import React, { useState, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { Plus, X, CheckCircle2, Circle, AlertCircle, Clock, CalendarDays } from 'lucide-react';
import { Task, Client, Lead, Project, TaskRelatedType } from '../types';

interface TasksProps {
  tasks: Task[];
  clients: Client[];
  leads: Lead[];
  projects: Project[];
  onAddTask: (t: Task) => void;
  onUpdateTask: (id: string, updates: Partial<Task>) => void;
  onDeleteTask: (id: string) => void;
  canWrite: boolean;
}

const emptyTask = (): Task => ({
  id: crypto.randomUUID(), title: '', notes: '', relatedType: undefined, relatedId: undefined,
  dueDate: new Date().toISOString().split('T')[0], completed: false, createdAt: new Date().toISOString(),
});

function dateBucket(dueDate?: string | null): 'overdue' | 'today' | 'upcoming' | 'none' {
  if (!dueDate) return 'none';
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const due = new Date(dueDate + 'T00:00:00');
  if (due.getTime() < today.getTime()) return 'overdue';
  if (due.getTime() === today.getTime()) return 'today';
  return 'upcoming';
}

export default function Tasks({ tasks, clients, leads, projects, onAddTask, onUpdateTask, onDeleteTask, canWrite }: TasksProps) {
  const [formTask, setFormTask] = useState<Task | null>(null);
  const [showCompleted, setShowCompleted] = useState(false);

  const relatedLabel = (t: Task) => {
    if (!t.relatedType || !t.relatedId) return null;
    if (t.relatedType === 'client') return clients.find(c => c.id === t.relatedId)?.name;
    if (t.relatedType === 'lead') return leads.find(l => l.id === t.relatedId)?.name;
    if (t.relatedType === 'project') return projects.find(p => p.id === t.relatedId)?.clientName;
    return null;
  };

  const groups = useMemo(() => {
    const open = tasks.filter(t => !t.completed);
    return {
      overdue: open.filter(t => dateBucket(t.dueDate) === 'overdue'),
      today: open.filter(t => dateBucket(t.dueDate) === 'today'),
      upcoming: open.filter(t => dateBucket(t.dueDate) === 'upcoming' || dateBucket(t.dueDate) === 'none'),
      completed: tasks.filter(t => t.completed),
    };
  }, [tasks]);

  const openNew = () => setFormTask(emptyTask());

  const handleSave = () => {
    if (!formTask || !formTask.title.trim()) return;
    onAddTask(formTask);
    setFormTask(null);
  };

  const Section = ({ title, icon, items, tone }: { title: string; icon: React.ReactNode; items: Task[]; tone: string }) => (
    <div>
      <h3 className={`text-sm font-semibold mb-2 flex items-center gap-2 ${tone}`}>{icon}{title} <span className="text-xs text-slate-400 font-normal">({items.length})</span></h3>
      <div className="space-y-2">
        {items.map(t => (
          <div key={t.id} className="flex items-start gap-3 bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 p-3">
            <button onClick={() => onUpdateTask(t.id, { completed: !t.completed })} className="mt-0.5 flex-shrink-0 text-slate-400 hover:text-emerald-500 transition-colors">
              {t.completed ? <CheckCircle2 className="w-5 h-5 text-emerald-500" /> : <Circle className="w-5 h-5" />}
            </button>
            <div className="flex-1 min-w-0">
              <p className={`text-sm font-medium ${t.completed ? 'line-through text-slate-400' : 'text-slate-900 dark:text-white'}`}>{t.title}</p>
              {t.notes && <p className="text-xs text-slate-500 mt-0.5">{t.notes}</p>}
              <div className="flex items-center gap-2 mt-1">
                {t.dueDate && <span className="text-[11px] text-slate-400 flex items-center gap-1"><CalendarDays className="w-3 h-3" />{t.dueDate}</span>}
                {relatedLabel(t) && <span className="text-[11px] px-1.5 py-0.5 bg-slate-100 dark:bg-slate-700 rounded text-slate-500">{relatedLabel(t)}</span>}
              </div>
            </div>
            <button onClick={() => onDeleteTask(t.id)} className="text-slate-300 hover:text-red-500 transition-colors"><X className="w-4 h-4" /></button>
          </div>
        ))}
        {items.length === 0 && <p className="text-xs text-slate-400">Nothing here.</p>}
      </div>
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-white">Tasks & Reminders</h2>
          <p className="text-sm text-slate-500 mt-1">Follow-ups on leads, clients, and projects.</p>
        </div>
        {canWrite && (
          <button onClick={openNew} className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 transition-colors">
            <Plus className="w-4 h-4" /> New Task
          </button>
        )}
      </div>

      <Section title="Overdue" icon={<AlertCircle className="w-4 h-4" />} items={groups.overdue} tone="text-red-600 dark:text-red-400" />
      <Section title="Due Today" icon={<Clock className="w-4 h-4" />} items={groups.today} tone="text-orange-600 dark:text-orange-400" />
      <Section title="Upcoming" icon={<CalendarDays className="w-4 h-4" />} items={groups.upcoming} tone="text-slate-600 dark:text-slate-300" />

      <div>
        <button onClick={() => setShowCompleted(!showCompleted)} className="text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 mb-2">
          {showCompleted ? 'Hide' : 'Show'} completed ({groups.completed.length})
        </button>
        {showCompleted && <Section title="Completed" icon={<CheckCircle2 className="w-4 h-4" />} items={groups.completed} tone="text-emerald-600 dark:text-emerald-400" />}
      </div>

      {formTask && createPortal(
        <div className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4" onClick={() => setFormTask(null)}>
          <div className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl w-full max-w-md" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700">
              <h3 className="font-semibold text-slate-800 dark:text-white">New Task</h3>
              <button onClick={() => setFormTask(null)} className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-white rounded-md"><X className="w-4 h-4" /></button>
            </div>
            <div className="p-4 space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Title *</label>
                <input type="text" value={formTask.title} onChange={e => setFormTask({ ...formTask, title: e.target.value })} placeholder="Follow up with..." className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg text-sm dark:text-white" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Due date</label>
                <input type="date" value={formTask.dueDate || ''} onChange={e => setFormTask({ ...formTask, dueDate: e.target.value })} className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg text-sm dark:text-white" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Link to</label>
                  <select
                    value={formTask.relatedType || ''}
                    onChange={e => setFormTask({ ...formTask, relatedType: (e.target.value || undefined) as TaskRelatedType | undefined, relatedId: undefined })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg text-sm dark:text-white"
                  >
                    <option value="">Nothing</option>
                    <option value="client">Client</option>
                    <option value="lead">Lead</option>
                    <option value="project">Project</option>
                  </select>
                </div>
                {formTask.relatedType && (
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1">Record</label>
                    <select
                      value={formTask.relatedId || ''}
                      onChange={e => setFormTask({ ...formTask, relatedId: e.target.value || undefined })}
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg text-sm dark:text-white"
                    >
                      <option value="">Select...</option>
                      {formTask.relatedType === 'client' && clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                      {formTask.relatedType === 'lead' && leads.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
                      {formTask.relatedType === 'project' && projects.map(p => <option key={p.id} value={p.id}>{p.clientName} — {p.workOrderNumber}</option>)}
                    </select>
                  </div>
                )}
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Notes</label>
                <textarea value={formTask.notes || ''} onChange={e => setFormTask({ ...formTask, notes: e.target.value })} rows={2} className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg text-sm dark:text-white" />
              </div>
            </div>
            <div className="flex justify-end gap-2 p-4 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 rounded-b-xl">
              <button onClick={() => setFormTask(null)} className="px-4 py-2 text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg">Cancel</button>
              <button onClick={handleSave} disabled={!formTask.title.trim()} className="px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 disabled:opacity-40">Create</button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}
