import React from 'react';
import { Project, Proforma, Invoice, CompanySettings } from '../types';
import { formatCurrency } from '../utils/formatters';

export const WorkOrderTemplate = ({ project, proforma, settings }: { project: Project, proforma: Proforma, settings: CompanySettings }) => (
  <div className="bg-white text-slate-900 p-8 font-sans">
    <div className="border-b-2 border-slate-900 pb-4 mb-6 flex justify-between items-end">
      <div>
        <h1 className="text-3xl font-bold uppercase tracking-widest text-slate-800">Internal Work Order</h1>
        <p className="text-sm font-semibold text-slate-500 mt-1">Ref: {project.workOrderNumber}</p>
      </div>
      <div className="text-right text-sm">
        <p><strong>Date Issued:</strong> {new Date().toLocaleDateString()}</p>
        <p><strong>Assigned Team:</strong> {project.assignedTeam}</p>
      </div>
    </div>

    <div className="mb-8 grid grid-cols-2 gap-8">
      <div>
        <h3 className="text-xs font-bold uppercase text-slate-400 mb-2 border-b border-slate-200 pb-1">Client Details</h3>
        <p className="font-bold">{project.clientName}</p>
        <p className="text-sm whitespace-pre-wrap">{proforma.clientAddress}</p>
        <p className="text-sm">{proforma.clientPhone}</p>
      </div>
      <div>
        <h3 className="text-xs font-bold uppercase text-slate-400 mb-2 border-b border-slate-200 pb-1">Project Timeline</h3>
        <p className="text-sm"><strong>Start Date:</strong> {project.startDate}</p>
        <p className="text-sm"><strong>Target Completion:</strong> {project.targetDate}</p>
        <p className="text-sm"><strong>Status:</strong> {project.status}</p>
      </div>
    </div>

    <div className="mb-8">
      <h3 className="text-xs font-bold uppercase text-slate-400 mb-2 border-b border-slate-200 pb-1">Approved Scope of Work</h3>
      <table className="w-full text-left text-sm mt-4 border-collapse">
        <thead>
          <tr className="bg-slate-100 text-slate-800">
            <th className="py-2 px-3 font-semibold">Qty/Unit</th>
            <th className="py-2 px-3 font-semibold w-full">Description / Task</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-200">
          {proforma.items.map((item, i) => (
            <tr key={i}>
              <td className="py-3 px-3 align-top whitespace-nowrap font-medium">{item.quantity} {item.unit}</td>
              <td className="py-3 px-3">{item.description}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>

    <div className="mt-16 pt-8 border-t border-slate-300 grid grid-cols-2 gap-16 text-center text-sm">
      <div>
        <div className="border-b border-slate-400 h-8 mb-2"></div>
        <p>Authorized By (Management)</p>
      </div>
      <div>
        <div className="border-b border-slate-400 h-8 mb-2"></div>
        <p>Accepted By (Assigned Team)</p>
      </div>
    </div>
  </div>
);

export const AcceptanceLetterTemplate = ({ project, proforma, settings }: { project: Project, proforma: Proforma, settings: CompanySettings }) => (
  <div className="bg-white text-slate-900 p-8 font-sans h-[1056px] flex flex-col">
    {settings.logoUrl && <img src={settings.logoUrl} alt="Logo" className="h-16 object-contain mb-8" crossOrigin="anonymous" />}
    
    <h1 className="text-2xl font-bold uppercase text-center mb-8">Project Completion & Acceptance</h1>
    
    <div className="space-y-4 text-sm mb-12">
      <p><strong>Date:</strong> {new Date().toLocaleDateString()}</p>
      <p><strong>Client:</strong> {project.clientName}</p>
      <p><strong>Project Ref:</strong> {project.workOrderNumber} (Proforma: {proforma.proformaNumber})</p>
    </div>

    <div className="prose prose-sm max-w-none text-slate-700 space-y-4 flex-1">
      <p>Dear {project.clientName},</p>
      <p>This document serves as formal confirmation that the work outlined in the agreed scope of work (Ref: {proforma.proformaNumber}) has been completed by {settings.companyName} according to the specified requirements.</p>
      <p>By signing below, you acknowledge that:</p>
      <ul className="list-disc pl-5 space-y-2">
        <li>The project deliverables have been received and inspected.</li>
        <li>The work meets the agreed-upon standards and specifications.</li>
        <li>Any provided training, handover materials, or required documentation has been received.</li>
        <li>This acceptance triggers the final invoicing stage for any outstanding balances.</li>
      </ul>
      <p className="mt-8">We appreciate the opportunity to work with you on this project.</p>
    </div>

    <div className="mt-auto grid grid-cols-2 gap-16 text-center text-sm">
      <div>
        <p className="text-left font-bold mb-8">For {settings.companyName}:</p>
        <div className="border-b border-slate-400 h-8 mb-2 relative">
          {settings.stampImageUrl && (
            <img src={settings.stampImageUrl} alt="Stamp" className="absolute bottom-0 left-1/2 -translate-x-1/2 max-h-24 opacity-80 mix-blend-multiply pointer-events-none" crossOrigin="anonymous" />
          )}
        </div>
        <p>Authorized Signature</p>
      </div>
      <div>
        <p className="text-left font-bold mb-8">For {project.clientName}:</p>
        <div className="border-b border-slate-400 h-8 mb-2"></div>
        <p>Client Signature & Date</p>
      </div>
    </div>
  </div>
);

export const InvoiceTemplate = ({ invoice, project, proforma, settings }: { invoice: Invoice, project: Project, proforma: Proforma, settings: CompanySettings }) => (
  <div className="bg-white text-slate-900 p-8 font-sans">
    <div className="flex justify-between items-start mb-12 border-b border-slate-200 pb-8">
      <div>
        {settings.logoUrl ? (
          <img src={settings.logoUrl} alt="Logo" className="h-16 object-contain mb-4" crossOrigin="anonymous" />
        ) : (
          <h2 className="text-2xl font-bold">{settings.companyName}</h2>
        )}
        <div className="text-sm text-slate-600 whitespace-pre-wrap mt-2">
          {settings.address && <p>{settings.address}</p>}
          {settings.email && <p>{settings.email}</p>}
        </div>
      </div>
      <div className="text-right">
        <h1 className="text-4xl font-light text-slate-800 uppercase tracking-widest mb-2">
          {invoice.type === 'Final Invoice' ? 'TAX INVOICE' : 'PAYMENT REQUEST'}
        </h1>
        <p className="text-lg font-bold text-slate-600">{invoice.invoiceNumber}</p>
        <div className="text-sm text-slate-500 mt-4 space-y-1">
          <p>Date: {invoice.date}</p>
          <p>Project Ref: {project.workOrderNumber}</p>
        </div>
      </div>
    </div>

    <div className="mb-12">
      <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Billed To</h3>
      <p className="font-bold text-lg">{project.clientName}</p>
      <p className="text-sm whitespace-pre-wrap text-slate-600">{proforma.clientAddress}</p>
    </div>

    <table className="w-full text-left text-sm mb-12 border-collapse">
      <thead>
        <tr className="border-b-2 border-slate-800">
          <th className="py-2 font-semibold">Description</th>
          <th className="py-2 font-semibold text-right">Amount</th>
        </tr>
      </thead>
      <tbody className="border-b border-slate-200">
        <tr>
          <td className="py-4">
            <p className="font-bold">{invoice.type}</p>
            <p className="text-slate-500 mt-1">{invoice.notes}</p>
            {invoice.type === 'Final Invoice' && (
              <p className="text-slate-500 text-xs mt-2">As per accepted proforma {proforma.proformaNumber}</p>
            )}
          </td>
          <td className="py-4 text-right font-medium">
            {formatCurrency(invoice.amount, settings.currency)}
          </td>
        </tr>
      </tbody>
    </table>

    <div className="flex justify-end mb-16">
      <div className="w-64">
        <div className="flex justify-between items-center border-t-2 border-slate-800 pt-2 font-bold text-lg">
          <span>Amount Due</span>
          <span>{formatCurrency(invoice.amount, settings.currency)}</span>
        </div>
      </div>
    </div>

    {settings.stampImageUrl && (
      <div className="flex justify-end relative">
        <div className="w-48 text-center relative z-10">
           <img src={settings.stampImageUrl} alt="Stamp" className="absolute bottom-4 left-1/2 -translate-x-1/2 max-w-[120px] max-h-[120px] opacity-90 mix-blend-multiply -z-10" crossOrigin="anonymous" />
           <div className="border-b border-slate-400 h-16 mb-2"></div>
           <p className="text-sm font-semibold">Authorized Signature</p>
        </div>
      </div>
    )}
  </div>
);
