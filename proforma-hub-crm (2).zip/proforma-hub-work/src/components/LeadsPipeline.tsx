import React, { useState } from 'react';
import { createPortal } from 'react-dom';
import { Plus, X, Phone, Mail, Building2, DollarSign, Trash2, FileText, ChevronRight, MessageSquarePlus, Tag } from 'lucide-react';
import { Lead, LeadActivity, LeadStage, LEAD_STAGES, CompanySettings } from '../types';
import { formatCurrency } from '../utils/formatters';

interface LeadsPipelineProps {
  leads: Lead[];
  leadActivities: LeadActivity[];
  settings: CompanySettings;
  onAddLead: (lead: Lead) => void;
  onUpdateLead: (id: string, updates: Partial<Lead>) => void;
  onDeleteLead: (id: string) => void;
  onAddActivity: (activity: LeadActivity) => void;
  onConvertToProforma: (lead: Lead) => void;
  canWrite: boolean;
}

const STAGE_STYLES: Record<LeadStage, { header: string; dot: string }> = {
  New: { header: 'text-slate-600 dark:text-slate-300', dot: 'bg-slate-400' },
  Contacted: { header: 'text-blue-600 dark:text-blue-400', dot: 'bg-blue-500' },
  Qualified: { header: 'text-indigo-600 dark:text-indigo-400', dot: 'bg-indigo-500' },
  Quoted: { header: 'text-purple-600 dark:text-purple-400', dot: 'bg-purple-500' },
  Won: { header: 'text-emerald-600 dark:text-emerald-400', dot: 'bg-emerald-500' },
  Lost: { header: 'text-red-500 dark:text-red-400', dot: 'bg-red-400' },
};

const emptyLead = (): Lead => ({
  id: crypto.randomUUID(),
  name: '',
  company: '',
  email: '',
  phone: '',
  address: '',
  source: '',
  estimatedValue: 0,
  stage: 'New',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
});

export default function LeadsPipeline({
  leads, leadActivities, settings, onAddLead, onUpdateLead, onDeleteLead, onAddActivity, onConvertToProforma, canWrite
}: LeadsPipelineProps) {
  const [formLead, setFormLead] = useState<Lead | null>(null); // non-null => modal open
  const [isNew, setIsNew] = useState(false);
  const [newNote, setNewNote] = useState('');
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [dragOverStage, setDragOverStage] = useState<LeadStage | null>(null);

  const openNewLead = () => { setFormLead(emptyLead()); setIsNew(true); };
  const openLead = (lead: Lead) => { setFormLead(lead); setIsNew(false); };
  const closeModal = () => { setFormLead(null); setNewNote(''); };

  const handleSaveLead = () => {
    if (!formLead || !formLead.name.trim()) return;
    if (isNew) {
      onAddLead(formLead);
    } else {
      onUpdateLead(formLead.id, formLead);
    }
    closeModal();
  };

  const handleDeleteLead = (id: string) => {
    if (confirm('Delete this lead? This cannot be undone.')) {
      onDeleteLead(id);
      closeModal();
    }
  };

  const handleAddNote = () => {
    if (!formLead || !newNote.trim()) return;
    onAddActivity({
      id: crypto.randomUUID(),
      leadId: formLead.id,
      note: newNote.trim(),
      date: new Date().toISOString(),
    });
    setNewNote('');
  };

  const moveStage = (lead: Lead, stage: LeadStage) => {
    onUpdateLead(lead.id, { stage });
    if (formLead && formLead.id === lead.id) setFormLead({ ...formLead, stage });
  };

  const handleDrop = (stage: LeadStage) => {
    if (draggingId) {
      onUpdateLead(draggingId, { stage });
    }
    setDraggingId(null);
    setDragOverStage(null);
  };

  const columnLeads = (stage: LeadStage) => leads.filter(l => l.stage === stage);
  const columnValue = (stage: LeadStage) =>
    columnLeads(stage).reduce((sum, l) => sum + (l.estimatedValue || 0), 0);

  const leadNotes = (leadId: string) =>
    leadActivities.filter(a => a.leadId === leadId).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="max-w-[1600px] mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-white">Leads Pipeline</h2>
          <p className="text-sm text-slate-500 mt-1">Track prospects from first contact through to a won (or lost) deal.</p>
        </div>
        {canWrite && (
          <button
            onClick={openNewLead}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 transition-colors"
          >
            <Plus className="w-4 h-4" /> New Lead
          </button>
        )}
      </div>

      {/* Board */}
      <div className="flex gap-4 overflow-x-auto pb-4 -mx-1 px-1">
        {LEAD_STAGES.map(stage => (
          <div
            key={stage}
            onDragOver={(e) => { e.preventDefault(); setDragOverStage(stage); }}
            onDragLeave={() => setDragOverStage(prev => (prev === stage ? null : prev))}
            onDrop={(e) => { e.preventDefault(); handleDrop(stage); }}
            className={`flex-shrink-0 w-72 rounded-xl border transition-colors ${
              dragOverStage === stage
                ? 'border-indigo-400 bg-indigo-50/60 dark:bg-indigo-500/10'
                : 'border-slate-200 dark:border-slate-700 bg-slate-100/60 dark:bg-slate-800/40'
            }`}
          >
            <div className="p-3 flex items-center justify-between sticky top-0">
              <div className="flex items-center gap-2">
                <span className={`w-2 h-2 rounded-full ${STAGE_STYLES[stage].dot}`}></span>
                <h3 className={`text-sm font-semibold ${STAGE_STYLES[stage].header}`}>{stage}</h3>
                <span className="text-xs text-slate-400 bg-white dark:bg-slate-700 px-1.5 py-0.5 rounded-full border border-slate-200 dark:border-slate-600">
                  {columnLeads(stage).length}
                </span>
              </div>
            </div>
            {columnValue(stage) > 0 && (
              <div className="px-3 pb-2 -mt-1 text-xs text-slate-500">
                {formatCurrency(columnValue(stage), settings.currency)}
              </div>
            )}

            <div className="p-2 space-y-2 min-h-[120px]">
              {columnLeads(stage).map(lead => (
                <div
                  key={lead.id}
                  draggable={canWrite}
                  onDragStart={() => canWrite && setDraggingId(lead.id)}
                  onDragEnd={() => { setDraggingId(null); setDragOverStage(null); }}
                  onClick={() => openLead(lead)}
                  className={`bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 p-3 shadow-sm hover:border-indigo-400 dark:hover:border-indigo-500 cursor-pointer transition-colors ${
                    draggingId === lead.id ? 'opacity-40' : ''
                  }`}
                >
                  <p className="font-semibold text-sm text-slate-900 dark:text-white truncate">{lead.name}</p>
                  {lead.company && (
                    <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5 truncate">
                      <Building2 className="w-3 h-3 flex-shrink-0" /> {lead.company}
                    </p>
                  )}
                  <div className="flex items-center justify-between mt-2">
                    {lead.estimatedValue ? (
                      <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400">
                        {formatCurrency(lead.estimatedValue, settings.currency)}
                      </span>
                    ) : <span />}
                    {lead.source && (
                      <span className="text-[10px] uppercase tracking-wide text-slate-400 flex items-center gap-1">
                        <Tag className="w-3 h-3" />{lead.source}
                      </span>
                    )}
                  </div>
                  {canWrite && stage !== 'Won' && stage !== 'Lost' && (
                    <div className="flex items-center gap-1 mt-2 pt-2 border-t border-slate-100 dark:border-slate-700">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          const idx = LEAD_STAGES.indexOf(stage);
                          if (idx < LEAD_STAGES.length - 1) moveStage(lead, LEAD_STAGES[idx + 1]);
                        }}
                        className="flex-1 inline-flex items-center justify-center gap-1 text-[11px] font-medium text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-500/10 rounded px-2 py-1 transition-colors"
                        title="Move to next stage"
                      >
                        Advance <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>
              ))}
              {columnLeads(stage).length === 0 && (
                <p className="text-xs text-slate-400 text-center py-6">No leads here</p>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Lead Detail / New Lead Modal */}
      {formLead && createPortal(
        <div className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4" onClick={closeModal}>
          <div
            className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700">
              <h3 className="font-semibold text-slate-800 dark:text-white">{isNew ? 'New Lead' : 'Lead Details'}</h3>
              <button onClick={closeModal} className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-white rounded-md">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2">
                  <label className="block text-xs font-medium text-slate-500 mb-1">Contact Name *</label>
                  <input
                    type="text"
                    value={formLead.name}
                    onChange={(e) => setFormLead({ ...formLead, name: e.target.value })}
                    placeholder="Jane Doe"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm dark:text-white"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-medium text-slate-500 mb-1">Company</label>
                  <input
                    type="text"
                    value={formLead.company || ''}
                    onChange={(e) => setFormLead({ ...formLead, company: e.target.value })}
                    placeholder="Acme Corp"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1 flex items-center gap-1"><Mail className="w-3 h-3" /> Email</label>
                  <input
                    type="email"
                    value={formLead.email}
                    onChange={(e) => setFormLead({ ...formLead, email: e.target.value })}
                    placeholder="jane@acme.com"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1 flex items-center gap-1"><Phone className="w-3 h-3" /> Phone</label>
                  <input
                    type="text"
                    value={formLead.phone}
                    onChange={(e) => setFormLead({ ...formLead, phone: e.target.value })}
                    placeholder="+1 555 000 0000"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1 flex items-center gap-1"><DollarSign className="w-3 h-3" /> Est. Value</label>
                  <input
                    type="number"
                    min="0"
                    value={formLead.estimatedValue || ''}
                    onChange={(e) => setFormLead({ ...formLead, estimatedValue: parseFloat(e.target.value) || 0 })}
                    placeholder="0"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Source</label>
                  <input
                    type="text"
                    value={formLead.source || ''}
                    onChange={(e) => setFormLead({ ...formLead, source: e.target.value })}
                    placeholder="Referral, Website..."
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm dark:text-white"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-medium text-slate-500 mb-1">Address</label>
                  <input
                    type="text"
                    value={formLead.address || ''}
                    onChange={(e) => setFormLead({ ...formLead, address: e.target.value })}
                    placeholder="Client address"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm dark:text-white"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-medium text-slate-500 mb-1">Stage</label>
                  <select
                    value={formLead.stage}
                    onChange={(e) => setFormLead({ ...formLead, stage: e.target.value as LeadStage })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm dark:text-white"
                  >
                    {LEAD_STAGES.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>

              {formLead.proformaId && (
                <div className="flex items-center gap-2 text-xs text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-500/10 px-3 py-2 rounded-lg">
                  <FileText className="w-3.5 h-3.5" /> Proforma already generated for this lead.
                </div>
              )}

              {!isNew && (
                <div className="border-t border-slate-200 dark:border-slate-700 pt-4">
                  <h4 className="text-xs font-semibold text-slate-500 mb-2 flex items-center gap-1">
                    <MessageSquarePlus className="w-3.5 h-3.5" /> Activity Notes
                  </h4>
                  <div className="flex gap-2 mb-3">
                    <input
                      type="text"
                      value={newNote}
                      onChange={(e) => setNewNote(e.target.value)}
                      onKeyDown={(e) => { if (e.key === 'Enter') handleAddNote(); }}
                      placeholder="Log a call, email, or note..."
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm dark:text-white"
                    />
                    <button onClick={handleAddNote} className="px-3 py-2 bg-slate-800 dark:bg-slate-700 text-white rounded-lg text-sm hover:bg-slate-900 dark:hover:bg-slate-600">
                      Add
                    </button>
                  </div>
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {leadNotes(formLead.id).length === 0 && (
                      <p className="text-xs text-slate-400">No activity logged yet.</p>
                    )}
                    {leadNotes(formLead.id).map(note => (
                      <div key={note.id} className="text-xs bg-slate-50 dark:bg-slate-900/50 rounded-lg p-2 border border-slate-100 dark:border-slate-700">
                        <p className="text-slate-700 dark:text-slate-300">{note.note}</p>
                        <p className="text-slate-400 mt-1">{new Date(note.date).toLocaleString()}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {canWrite && (
              <div className="flex items-center justify-between gap-2 p-4 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 rounded-b-xl">
                {!isNew ? (
                  <button
                    onClick={() => handleDeleteLead(formLead.id)}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-red-600 dark:text-red-400 text-sm font-medium hover:bg-red-50 dark:hover:bg-red-500/10 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4" /> Delete
                  </button>
                ) : <span />}
                <div className="flex gap-2">
                  {!isNew && (
                    <button
                      onClick={() => { onConvertToProforma(formLead); closeModal(); }}
                      className="inline-flex items-center gap-1.5 px-4 py-2 bg-purple-600 text-white text-sm font-medium rounded-lg hover:bg-purple-700 transition-colors"
                    >
                      <FileText className="w-4 h-4" /> Convert to Proforma
                    </button>
                  )}
                  <button
                    onClick={handleSaveLead}
                    disabled={!formLead.name.trim()}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 disabled:opacity-40 transition-colors"
                  >
                    {isNew ? 'Create Lead' : 'Save Changes'}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}
