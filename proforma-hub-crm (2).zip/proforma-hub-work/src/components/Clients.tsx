import React, { useState, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { Plus, X, Search, Building2, Mail, Phone, Trash2, FileText, Briefcase, Target, MapPin } from 'lucide-react';
import { Client, Lead, Proforma, Project, CompanySettings, UserRole } from '../types';
import { formatCurrency } from '../utils/formatters';

interface ClientsProps {
  clients: Client[];
  leads: Lead[];
  proformas: Proforma[];
  projects: Project[];
  settings: CompanySettings;
  role: UserRole | null;
  onAddClient: (c: Client) => void;
  onUpdateClient: (id: string, updates: Partial<Client>) => void;
  onDeleteClient: (id: string) => void;
  onCreateProformaForClient: (client: Client) => void;
}

const emptyClient = (): Client => ({
  id: crypto.randomUUID(), name: '', company: '', email: '', phone: '', address: '', notes: '',
  createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
});

export default function Clients({
  clients, leads, proformas, projects, settings, role, onAddClient, onUpdateClient, onDeleteClient, onCreateProformaForClient
}: ClientsProps) {
  const canWrite = role === 'owner' || role === 'sales';
  const [search, setSearch] = useState('');
  const [formClient, setFormClient] = useState<Client | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [detailClient, setDetailClient] = useState<Client | null>(null);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return clients.filter(c => c.name.toLowerCase().includes(q) || (c.company || '').toLowerCase().includes(q) || c.email.toLowerCase().includes(q));
  }, [clients, search]);

  const openNew = () => { setFormClient(emptyClient()); setIsNew(true); };
  const openEdit = (c: Client) => { setFormClient(c); setIsNew(false); };
  const closeForm = () => setFormClient(null);

  const handleSave = () => {
    if (!formClient || !formClient.name.trim()) return;
    if (isNew) onAddClient(formClient); else onUpdateClient(formClient.id, formClient);
    if (detailClient && detailClient.id === formClient.id) setDetailClient(formClient);
    closeForm();
  };

  const handleDelete = (id: string) => {
    if (confirm('Delete this client? Linked leads/proformas/projects will keep their data but lose the client link.')) {
      onDeleteClient(id);
      setDetailClient(null);
      closeForm();
    }
  };

  const relatedLeads = (clientId: string) => leads.filter(l => l.clientId === clientId);
  const relatedProformas = (clientId: string) => proformas.filter(p => p.clientId === clientId);
  const relatedProjects = (clientId: string) => projects.filter(p => p.clientId === clientId);

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-white">Clients</h2>
          <p className="text-sm text-slate-500 mt-1">Every lead, proforma, and project rolls up to a client record here.</p>
        </div>
        {canWrite && (
          <button onClick={openNew} className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 transition-colors">
            <Plus className="w-4 h-4" /> New Client
          </button>
        )}
      </div>

      <div className="relative max-w-sm">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search clients..."
          className="w-full pl-9 pr-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 dark:text-white"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(client => (
          <div
            key={client.id}
            onClick={() => setDetailClient(client)}
            className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 p-5 shadow-sm hover:border-indigo-400 dark:hover:border-indigo-500 cursor-pointer transition-colors"
          >
            <h3 className="font-bold text-slate-900 dark:text-white">{client.name}</h3>
            {client.company && <p className="text-sm text-slate-500 flex items-center gap-1 mt-0.5"><Building2 className="w-3.5 h-3.5" />{client.company}</p>}
            {client.email && <p className="text-xs text-slate-400 flex items-center gap-1 mt-2"><Mail className="w-3 h-3" />{client.email}</p>}
            <div className="flex items-center gap-3 mt-4 pt-3 border-t border-slate-100 dark:border-slate-700 text-xs text-slate-500">
              <span className="flex items-center gap-1"><Target className="w-3 h-3" />{relatedLeads(client.id).length} leads</span>
              <span className="flex items-center gap-1"><FileText className="w-3 h-3" />{relatedProformas(client.id).length} proformas</span>
              <span className="flex items-center gap-1"><Briefcase className="w-3 h-3" />{relatedProjects(client.id).length} projects</span>
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <p className="text-slate-500 col-span-full text-center py-12">
            {clients.length === 0 ? 'No clients yet. Add one, or convert a lead to auto-create one.' : 'No clients match your search.'}
          </p>
        )}
      </div>

      {/* Detail panel */}
      {detailClient && createPortal(
        <div className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4" onClick={() => setDetailClient(null)}>
          <div className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700">
              <div>
                <h3 className="font-bold text-slate-900 dark:text-white">{detailClient.name}</h3>
                {detailClient.company && <p className="text-xs text-slate-500">{detailClient.company}</p>}
              </div>
              <button onClick={() => setDetailClient(null)} className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-white rounded-md"><X className="w-4 h-4" /></button>
            </div>

            <div className="p-4 space-y-5">
              <div className="grid grid-cols-2 gap-3 text-sm">
                {detailClient.email && <p className="flex items-center gap-2 text-slate-600 dark:text-slate-300"><Mail className="w-3.5 h-3.5 text-slate-400" />{detailClient.email}</p>}
                {detailClient.phone && <p className="flex items-center gap-2 text-slate-600 dark:text-slate-300"><Phone className="w-3.5 h-3.5 text-slate-400" />{detailClient.phone}</p>}
                {detailClient.address && <p className="flex items-center gap-2 text-slate-600 dark:text-slate-300 col-span-2"><MapPin className="w-3.5 h-3.5 text-slate-400" />{detailClient.address}</p>}
              </div>
              {detailClient.notes && <p className="text-sm text-slate-500 bg-slate-50 dark:bg-slate-900/50 rounded-lg p-3">{detailClient.notes}</p>}

              <div>
                <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Leads ({relatedLeads(detailClient.id).length})</h4>
                <div className="space-y-1.5">
                  {relatedLeads(detailClient.id).map(l => (
                    <div key={l.id} className="flex justify-between text-sm bg-slate-50 dark:bg-slate-900/50 rounded-lg px-3 py-2">
                      <span className="text-slate-700 dark:text-slate-300">{l.stage}</span>
                      <span className="font-medium text-slate-900 dark:text-white">{l.estimatedValue ? formatCurrency(l.estimatedValue, settings.currency) : '—'}</span>
                    </div>
                  ))}
                  {relatedLeads(detailClient.id).length === 0 && <p className="text-xs text-slate-400">No leads linked yet.</p>}
                </div>
              </div>

              <div>
                <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Proformas ({relatedProformas(detailClient.id).length})</h4>
                <div className="space-y-1.5">
                  {relatedProformas(detailClient.id).map(p => (
                    <div key={p.id} className="flex justify-between text-sm bg-slate-50 dark:bg-slate-900/50 rounded-lg px-3 py-2">
                      <span className="text-slate-700 dark:text-slate-300">{p.proformaNumber} · {p.status}</span>
                      <span className="font-medium text-slate-900 dark:text-white">{formatCurrency(p.grandTotal, settings.currency)}</span>
                    </div>
                  ))}
                  {relatedProformas(detailClient.id).length === 0 && <p className="text-xs text-slate-400">No proformas yet.</p>}
                </div>
              </div>

              <div>
                <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Projects ({relatedProjects(detailClient.id).length})</h4>
                <div className="space-y-1.5">
                  {relatedProjects(detailClient.id).map(p => (
                    <div key={p.id} className="flex justify-between text-sm bg-slate-50 dark:bg-slate-900/50 rounded-lg px-3 py-2">
                      <span className="text-slate-700 dark:text-slate-300">{p.workOrderNumber} · {p.status}</span>
                      <span className="font-medium text-slate-900 dark:text-white">{formatCurrency(p.contractValue, settings.currency)}</span>
                    </div>
                  ))}
                  {relatedProjects(detailClient.id).length === 0 && <p className="text-xs text-slate-400">No projects yet.</p>}
                </div>
              </div>
            </div>

            {canWrite && (
              <div className="flex items-center justify-between gap-2 p-4 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 rounded-b-xl">
                <button onClick={() => handleDelete(detailClient.id)} className="inline-flex items-center gap-1.5 px-3 py-2 text-red-600 dark:text-red-400 text-sm font-medium hover:bg-red-50 dark:hover:bg-red-500/10 rounded-lg transition-colors">
                  <Trash2 className="w-4 h-4" /> Delete
                </button>
                <div className="flex gap-2">
                  <button onClick={() => openEdit(detailClient)} className="px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-white text-sm font-medium rounded-lg hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors">Edit</button>
                  <button onClick={() => { onCreateProformaForClient(detailClient); setDetailClient(null); }} className="inline-flex items-center gap-1.5 px-4 py-2 bg-purple-600 text-white text-sm font-medium rounded-lg hover:bg-purple-700 transition-colors">
                    <FileText className="w-4 h-4" /> New Proforma
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>,
        document.body
      )}

      {/* Add/Edit form */}
      {formClient && createPortal(
        <div className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4" onClick={closeForm}>
          <div className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl w-full max-w-md" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700">
              <h3 className="font-semibold text-slate-800 dark:text-white">{isNew ? 'New Client' : 'Edit Client'}</h3>
              <button onClick={closeForm} className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-white rounded-md"><X className="w-4 h-4" /></button>
            </div>
            <div className="p-4 space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Name *</label>
                <input type="text" value={formClient.name} onChange={e => setFormClient({ ...formClient, name: e.target.value })} className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg text-sm dark:text-white" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Company</label>
                <input type="text" value={formClient.company || ''} onChange={e => setFormClient({ ...formClient, company: e.target.value })} className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg text-sm dark:text-white" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Email</label>
                  <input type="email" value={formClient.email} onChange={e => setFormClient({ ...formClient, email: e.target.value })} className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg text-sm dark:text-white" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Phone</label>
                  <input type="text" value={formClient.phone} onChange={e => setFormClient({ ...formClient, phone: e.target.value })} className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg text-sm dark:text-white" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Address</label>
                <input type="text" value={formClient.address || ''} onChange={e => setFormClient({ ...formClient, address: e.target.value })} className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg text-sm dark:text-white" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Notes</label>
                <textarea value={formClient.notes || ''} onChange={e => setFormClient({ ...formClient, notes: e.target.value })} rows={2} className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg text-sm dark:text-white" />
              </div>
            </div>
            <div className="flex justify-end gap-2 p-4 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 rounded-b-xl">
              <button onClick={closeForm} className="px-4 py-2 text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg">Cancel</button>
              <button onClick={handleSave} disabled={!formClient.name.trim()} className="px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 disabled:opacity-40">
                {isNew ? 'Create' : 'Save'}
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}
