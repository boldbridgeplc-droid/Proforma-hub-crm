import React, { useState } from 'react';
import { Proforma, CompanySettings, Project } from '../types';
import { Search, FileText, Download, Trash2, Edit, CheckCircle, ArrowRight } from 'lucide-react';
import { formatCurrency } from '../utils/formatters';
import html2pdf from 'html2pdf.js';
import ProformaPreview from './ProformaPreview';
import { createPortal } from 'react-dom';

interface HistoryProps {
  proformas: Proforma[];
  onUpdateProforma: (proforma: Proforma) => void;
  onDeleteProforma: (id: string) => void;
  onEdit: (proforma: Proforma) => void;
  settings: CompanySettings;
  onConvertToProject: (project: Project) => void;
  canWrite: boolean;
}

export default function History({ proformas, onUpdateProforma, onDeleteProforma, onEdit, settings, onConvertToProject, canWrite }: HistoryProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [hiddenPreview, setHiddenPreview] = useState<Proforma | null>(null);

  const filteredProformas = proformas.filter(p => 
    p.proformaNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.clientName.toLowerCase().includes(searchTerm.toLowerCase())
  ).sort((a, b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime());

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this proforma?')) {
      onDeleteProforma(id);
    }
  };

  const handleStatusChange = (id: string, newStatus: Proforma['status']) => {
    const target = proformas.find(p => p.id === id);
    if (target) onUpdateProforma({ ...target, status: newStatus });
  };

  const handleConvertToProject = (proforma: Proforma) => {
    if (confirm('Convert this accepted proforma to a new Active Project?')) {
      const newProject: Project = {
        id: crypto.randomUUID(),
        proformaId: proforma.id,
        clientName: proforma.clientName,
        workOrderNumber: `WO-${new Date().getFullYear()}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`,
        assignedTeam: 'Unassigned',
        startDate: new Date().toISOString().split('T')[0],
        targetDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        status: 'In Progress',
        contractValue: proforma.grandTotal,
        createdAt: new Date().toISOString(),
      };
      
      onConvertToProject(newProject);
      handleStatusChange(proforma.id, 'Converted');
    }
  };

  const handleDownload = (proforma: Proforma) => {
    setHiddenPreview(proforma);
    
    // Give react time to render the hidden component
    setTimeout(() => {
      const element = document.getElementById('hidden-preview-container');
      if (!element) return;
      
      const opt = {
        margin:       0.3,
        filename:     `${proforma.proformaNumber}.pdf`,
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2, useCORS: true },
        jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' },
        pagebreak:    { mode: ['css', 'legacy'] }
      };
      
      html2pdf().set(opt).from(element).save().then(() => {
        setHiddenPreview(null);
      });
    }, 100);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      
      {/* Hidden Preview for PDF Generation */}
      {hiddenPreview && createPortal(
        <div id="hidden-preview-container" className="fixed top-0 left-[-9999px] w-[800px] opacity-0 pointer-events-none">
          <ProformaPreview proforma={hiddenPreview} settings={settings} />
        </div>,
        document.body
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-slate-900 dark:text-white">Proforma History</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Manage and track your issued proforma invoices.</p>
        </div>
        
        <div className="relative max-w-sm w-full">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-slate-400" />
          </div>
          <input
            type="text"
            placeholder="Search by client or invoice number..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:text-white shadow-sm transition-colors"
          />
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm whitespace-nowrap">
            <thead className="bg-slate-50 dark:bg-slate-900/50 text-slate-600 dark:text-slate-400">
              <tr>
                <th className="px-6 py-3 font-medium">Proforma No.</th>
                <th className="px-6 py-3 font-medium">Client</th>
                <th className="px-6 py-3 font-medium">Date</th>
                <th className="px-6 py-3 font-medium text-right">Amount</th>
                <th className="px-6 py-3 font-medium text-center">Status</th>
                <th className="px-6 py-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700">
              {filteredProformas.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center">
                    <div className="flex flex-col items-center justify-center text-slate-400 dark:text-slate-500">
                      <FileText className="h-10 w-10 mb-3 opacity-20" />
                      <p className="text-base font-medium">No proformas found</p>
                      <p className="text-sm mt-1">Create your first proforma invoice to see it here.</p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredProformas.map((proforma) => (
                  <tr key={proforma.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    <td className="px-6 py-4 font-medium text-indigo-600 dark:text-indigo-400">
                      {proforma.proformaNumber}
                    </td>
                    <td className="px-6 py-4 text-slate-900 dark:text-white">
                      {proforma.clientName || '-'}
                    </td>
                    <td className="px-6 py-4 text-slate-600 dark:text-slate-300">
                      {proforma.issueDate}
                    </td>
                    <td className="px-6 py-4 text-slate-900 dark:text-white font-medium text-right">
                      {formatCurrency(proforma.grandTotal, settings.currency)}
                    </td>
                    <td className="px-6 py-4 text-center">
                      <select
                        value={proforma.status}
                        onChange={(e) => handleStatusChange(proforma.id, e.target.value as Proforma['status'])}
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border-0 cursor-pointer disabled:cursor-default ${
                          proforma.status === 'Draft' ? 'bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-300' :
                          proforma.status === 'Sent' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300' :
                          proforma.status === 'Accepted' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300' :
                          proforma.status === 'Converted' ? 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300' :
                          'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
                        }`}
                        disabled={proforma.status === 'Converted' || !canWrite}
                      >
                        <option value="Draft">Draft</option>
                        <option value="Sent">Sent</option>
                        <option value="Accepted">Accepted</option>
                        <option value="Rejected">Rejected</option>
                        <option value="Converted" disabled>Converted</option>
                      </select>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-2 text-slate-400">
                        {proforma.status === 'Accepted' && canWrite && (
                          <button
                            onClick={() => handleConvertToProject(proforma)}
                            className="p-1.5 text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 transition-colors tooltip flex items-center"
                            title="Convert to Project"
                          >
                            <ArrowRight className="w-4 h-4" />
                          </button>
                        )}
                        {canWrite && (
                          <button
                            onClick={() => onEdit(proforma)}
                            className="p-1.5 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors tooltip"
                            title="Edit"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                        )}
                        <button
                          onClick={() => handleDownload(proforma)}
                          className="p-1.5 hover:text-slate-900 dark:hover:text-white transition-colors"
                          title="Download PDF"
                        >
                          <Download className="w-4 h-4" />
                        </button>
                        {canWrite && (
                          <button
                            onClick={() => handleDelete(proforma.id)}
                            className="p-1.5 hover:text-red-600 transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
