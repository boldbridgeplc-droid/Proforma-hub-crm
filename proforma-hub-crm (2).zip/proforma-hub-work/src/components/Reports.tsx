import React, { useMemo } from 'react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { TrendingUp, Target, Percent, DollarSign } from 'lucide-react';
import { Lead, Proforma, Invoice, LEAD_STAGES, CompanySettings } from '../types';
import { formatCurrency } from '../utils/formatters';

interface ReportsProps {
  leads: Lead[];
  proformas: Proforma[];
  invoices: Invoice[];
  settings: CompanySettings;
}

const STAGE_WEIGHT: Record<string, number> = { New: 0.1, Contacted: 0.25, Qualified: 0.5, Quoted: 0.75, Won: 1, Lost: 0 };
const STAGE_COLOR: Record<string, string> = { New: '#94a3b8', Contacted: '#3b82f6', Qualified: '#6366f1', Quoted: '#a855f7', Won: '#10b981', Lost: '#f87171' };

export default function Reports({ leads, proformas, invoices, settings }: ReportsProps) {
  const pipelineData = useMemo(() => LEAD_STAGES.map(stage => ({
    stage,
    count: leads.filter(l => l.stage === stage).length,
    value: leads.filter(l => l.stage === stage).reduce((s, l) => s + (l.estimatedValue || 0), 0),
  })), [leads]);

  const winRate = useMemo(() => {
    const won = leads.filter(l => l.stage === 'Won').length;
    const lost = leads.filter(l => l.stage === 'Lost').length;
    const total = won + lost;
    return total > 0 ? (won / total) * 100 : 0;
  }, [leads]);

  const forecast = useMemo(() => {
    return leads
      .filter(l => l.stage !== 'Won' && l.stage !== 'Lost')
      .reduce((sum, l) => sum + (l.estimatedValue || 0) * (STAGE_WEIGHT[l.stage] || 0), 0);
  }, [leads]);

  const openPipelineValue = useMemo(() =>
    leads.filter(l => l.stage !== 'Won' && l.stage !== 'Lost').reduce((s, l) => s + (l.estimatedValue || 0), 0),
    [leads]
  );

  const revenueByMonth = useMemo(() => {
    const map = new Map<string, number>();
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      map.set(d.toLocaleDateString('en-US', { month: 'short', year: '2-digit' }), 0);
    }
    invoices.filter(inv => inv.status === 'Paid').forEach(inv => {
      const d = new Date(inv.date);
      const key = d.toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
      if (map.has(key)) map.set(key, (map.get(key) || 0) + inv.amount);
    });
    return Array.from(map.entries()).map(([month, amount]) => ({ month, amount }));
  }, [invoices]);

  const proformaStatusData = useMemo(() => {
    const statuses: Proforma['status'][] = ['Draft', 'Sent', 'Accepted', 'Rejected', 'Converted'];
    return statuses.map(status => ({ status, count: proformas.filter(p => p.status === status).length }));
  }, [proformas]);

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-800 dark:text-white">Reports & Forecasting</h2>
        <p className="text-sm text-slate-500 mt-1">Pipeline health, win rate, and revenue trends.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Weighted Forecast</span>
            <TrendingUp className="w-4 h-4 text-indigo-500" />
          </div>
          <p className="text-2xl font-bold text-slate-900 dark:text-white">{formatCurrency(forecast, settings.currency)}</p>
          <p className="text-xs text-slate-400 mt-1">Open pipeline weighted by stage</p>
        </div>
        <div className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Open Pipeline Value</span>
            <DollarSign className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="text-2xl font-bold text-slate-900 dark:text-white">{formatCurrency(openPipelineValue, settings.currency)}</p>
          <p className="text-xs text-slate-400 mt-1">Unweighted, all open leads</p>
        </div>
        <div className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Win Rate</span>
            <Percent className="w-4 h-4 text-purple-500" />
          </div>
          <p className="text-2xl font-bold text-slate-900 dark:text-white">{winRate.toFixed(0)}%</p>
          <p className="text-xs text-slate-400 mt-1">Of closed leads (won vs. lost)</p>
        </div>
        <div className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Active Leads</span>
            <Target className="w-4 h-4 text-blue-500" />
          </div>
          <p className="text-2xl font-bold text-slate-900 dark:text-white">{leads.filter(l => l.stage !== 'Won' && l.stage !== 'Lost').length}</p>
          <p className="text-xs text-slate-400 mt-1">In active pipeline stages</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm p-6">
          <h3 className="text-sm font-bold text-slate-800 dark:text-white mb-4">Pipeline by Stage</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={pipelineData}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-slate-200 dark:stroke-slate-700" />
              <XAxis dataKey="stage" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip formatter={(value: any, name: string) => name === 'count' ? [value, 'Leads'] : [formatCurrency(value, settings.currency), 'Value']} />
              <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                {pipelineData.map((entry, i) => <Cell key={i} fill={STAGE_COLOR[entry.stage]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm p-6">
          <h3 className="text-sm font-bold text-slate-800 dark:text-white mb-4">Collected Revenue (Last 6 Months)</h3>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={revenueByMonth}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-slate-200 dark:stroke-slate-700" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => formatCurrency(v, settings.currency)} width={70} />
              <Tooltip formatter={(value: any) => formatCurrency(value, settings.currency)} />
              <Line type="monotone" dataKey="amount" stroke="#6366f1" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm p-6">
        <h3 className="text-sm font-bold text-slate-800 dark:text-white mb-4">Proforma Status Breakdown</h3>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={proformaStatusData} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" className="stroke-slate-200 dark:stroke-slate-700" />
            <XAxis type="number" tick={{ fontSize: 11 }} allowDecimals={false} />
            <YAxis type="category" dataKey="status" tick={{ fontSize: 11 }} width={80} />
            <Tooltip />
            <Bar dataKey="count" fill="#6366f1" radius={[0, 4, 4, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
