import React from 'react';
import { Database, Terminal, Copy, Check } from 'lucide-react';

export default function SetupNeeded() {
  const [copied, setCopied] = React.useState(false);
  const envSnippet = 'VITE_SUPABASE_URL=https://your-project-ref.supabase.co\nVITE_SUPABASE_ANON_KEY=your-anon-public-key';

  const copy = () => {
    navigator.clipboard.writeText(envSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex items-center justify-center p-4">
      <div className="max-w-lg w-full bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 p-8">
        <div className="w-12 h-12 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-xl flex items-center justify-center mb-4">
          <Database className="w-6 h-6" />
        </div>
        <h1 className="text-xl font-bold text-slate-900 dark:text-white mb-2">Connect a backend to get started</h1>
        <p className="text-sm text-slate-500 mb-6">
          This app now runs on a real multi-user database (Supabase) instead of your browser's local storage. Three quick steps:
        </p>

        <ol className="space-y-4 text-sm text-slate-700 dark:text-slate-300">
          <li className="flex gap-3">
            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-indigo-100 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 flex items-center justify-center text-xs font-bold">1</span>
            <span>
              Create a free project at{' '}
              <a href="https://supabase.com" target="_blank" rel="noreferrer" className="text-indigo-600 dark:text-indigo-400 hover:underline">supabase.com</a>.
            </span>
          </li>
          <li className="flex gap-3">
            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-indigo-100 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 flex items-center justify-center text-xs font-bold">2</span>
            <span>
              Open the SQL Editor in your project, paste in the contents of <code className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-900 rounded text-xs">supabase/schema.sql</code> from this project, and run it. This creates every table, security rule, and the auto-profile trigger.
            </span>
          </li>
          <li className="flex gap-3">
            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-indigo-100 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 flex items-center justify-center text-xs font-bold">3</span>
            <span>
              In Project Settings → API, copy your <strong>Project URL</strong> and <strong>anon public key</strong>. Create a file named <code className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-900 rounded text-xs">.env.local</code> in the project root with:
            </span>
          </li>
        </ol>

        <div className="mt-4 relative">
          <pre className="bg-slate-900 text-slate-100 text-xs rounded-lg p-4 overflow-x-auto flex items-center gap-2">
            <Terminal className="w-4 h-4 flex-shrink-0 text-slate-500" />
            <code>{envSnippet}</code>
          </pre>
          <button
            onClick={copy}
            className="absolute top-2 right-2 p-1.5 bg-slate-800 hover:bg-slate-700 rounded-md text-slate-300"
            title="Copy"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>

        <p className="text-xs text-slate-400 mt-6">
          Then restart <code className="px-1 bg-slate-100 dark:bg-slate-900 rounded">npm run dev</code>. The first account you sign up with becomes the workspace Owner.
        </p>
      </div>
    </div>
  );
}
