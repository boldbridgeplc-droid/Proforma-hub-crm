import React from 'react';
import { CompanySettings, Profile, UserRole } from '../types';
import { Save, Building2, Landmark, Percent, Image as ImageIcon, Upload, Plus, Trash2, FileText, Users, Lock } from 'lucide-react';

interface SettingsProps {
  settings: CompanySettings;
  setSettings: (settings: CompanySettings) => void;
  role: UserRole | null;
  currentUserId?: string;
  team?: Profile[];
  onUpdateTeamRole?: (userId: string, role: UserRole) => void;
}

const ROLE_DESCRIPTIONS: Record<UserRole, string> = {
  owner: 'Full access, including settings and team management',
  sales: 'Manages clients, leads, and proformas',
  finance: 'Manages projects, expenses, and invoices',
  viewer: 'Read-only access everywhere',
};

export default function Settings({ settings, setSettings, role, currentUserId, team = [], onUpdateTeamRole }: SettingsProps) {
  const [localSettings, setLocalSettings] = React.useState<CompanySettings>(settings);
  const [savedMessage, setSavedMessage] = React.useState(false);
  const isOwner = role === 'owner';

  React.useEffect(() => { setLocalSettings(settings); }, [settings]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setLocalSettings((prev) => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) || 0 : value,
    }));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSettings(localSettings);
    setSavedMessage(true);
    setTimeout(() => setSavedMessage(false), 3000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, fieldName: keyof CompanySettings) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setLocalSettings(prev => ({
          ...prev,
          [fieldName]: reader.result as string
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold text-slate-900 dark:text-white">Company Settings</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Configure your business details to auto-fill future proformas.</p>
        </div>
      </div>

      {!isOwner && (
        <div className="flex items-center gap-2 text-sm text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/30 rounded-lg px-4 py-3">
          <Lock className="w-4 h-4 flex-shrink-0" /> Only the workspace Owner can change company settings. You're viewing in read-only mode.
        </div>
      )}

      <form onSubmit={handleSave} className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
        <fieldset disabled={!isOwner} className="p-6 space-y-8">
          {/* Business Info Section */}
          <section>
            <h3 className="text-sm font-medium text-slate-900 dark:text-slate-200 flex items-center gap-2 mb-4 uppercase tracking-wider">
              <Building2 className="w-4 h-4 text-indigo-500" />
              Business Identity
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Company Name</label>
                <input
                  type="text"
                  name="companyName"
                  value={localSettings.companyName}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:text-white transition-colors"
                  placeholder="Acme Corp"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Logo URL or Upload</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <ImageIcon className="h-4 w-4 text-slate-400" />
                    </div>
                    <input
                      type="text"
                      name="logoUrl"
                      value={localSettings.logoUrl}
                      onChange={handleChange}
                      className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:text-white transition-colors"
                      placeholder="https://example.com/logo.png"
                    />
                  </div>
                  <label className="flex items-center justify-center px-4 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors" title="Upload Local File">
                    <Upload className="w-4 h-4 text-slate-600 dark:text-slate-300" />
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => handleFileUpload(e, 'logoUrl')} />
                  </label>
                </div>
              </div>

              <div className="space-y-1 md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Address</label>
                <textarea
                  name="address"
                  value={localSettings.address}
                  onChange={handleChange}
                  rows={3}
                  className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:text-white transition-colors resize-none"
                  placeholder="123 Business Rd..."
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Email Address</label>
                <input
                  type="email"
                  name="email"
                  value={localSettings.email}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:text-white transition-colors"
                  placeholder="billing@example.com"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Phone Number</label>
                <input
                  type="text"
                  name="phone"
                  value={localSettings.phone}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:text-white transition-colors"
                  placeholder="+1 (555) 000-0000"
                />
              </div>
            </div>
          </section>

          <hr className="border-slate-200 dark:border-slate-700" />

          {/* Branding Assets Section */}
          <section>
            <h3 className="text-sm font-medium text-slate-900 dark:text-slate-200 flex items-center gap-2 mb-4 uppercase tracking-wider">
              <ImageIcon className="w-4 h-4 text-pink-500" />
              Branding Assets
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Header Image URL (Optional Banner)</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <ImageIcon className="h-4 w-4 text-slate-400" />
                    </div>
                    <input
                      type="text"
                      name="headerImageUrl"
                      value={localSettings.headerImageUrl || ''}
                      onChange={handleChange}
                      className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:text-white transition-colors"
                      placeholder="https://example.com/header.png"
                    />
                  </div>
                  <label className="flex items-center justify-center px-4 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors" title="Upload Local File">
                    <Upload className="w-4 h-4 text-slate-600 dark:text-slate-300" />
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => handleFileUpload(e, 'headerImageUrl')} />
                  </label>
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Company Stamp Image URL</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <ImageIcon className="h-4 w-4 text-slate-400" />
                    </div>
                    <input
                      type="text"
                      name="stampImageUrl"
                      value={localSettings.stampImageUrl || ''}
                      onChange={handleChange}
                      className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:text-white transition-colors"
                      placeholder="https://example.com/stamp.png"
                    />
                  </div>
                  <label className="flex items-center justify-center px-4 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors" title="Upload Local File">
                    <Upload className="w-4 h-4 text-slate-600 dark:text-slate-300" />
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => handleFileUpload(e, 'stampImageUrl')} />
                  </label>
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Footer Image 1 URL</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <ImageIcon className="h-4 w-4 text-slate-400" />
                    </div>
                    <input
                      type="text"
                      name="footerImage1Url"
                      value={localSettings.footerImage1Url || ''}
                      onChange={handleChange}
                      className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:text-white transition-colors"
                      placeholder="https://example.com/footer1.png"
                    />
                  </div>
                  <label className="flex items-center justify-center px-4 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors" title="Upload Local File">
                    <Upload className="w-4 h-4 text-slate-600 dark:text-slate-300" />
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => handleFileUpload(e, 'footerImage1Url')} />
                  </label>
                </div>
              </div>
              
              <div className="space-y-1">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Footer Image 2 URL</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <ImageIcon className="h-4 w-4 text-slate-400" />
                    </div>
                    <input
                      type="text"
                      name="footerImage2Url"
                      value={localSettings.footerImage2Url || ''}
                      onChange={handleChange}
                      className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:text-white transition-colors"
                      placeholder="https://example.com/footer2.png"
                    />
                  </div>
                  <label className="flex items-center justify-center px-4 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors" title="Upload Local File">
                    <Upload className="w-4 h-4 text-slate-600 dark:text-slate-300" />
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => handleFileUpload(e, 'footerImage2Url')} />
                  </label>
                </div>
              </div>
            </div>
          </section>

          <hr className="border-slate-200 dark:border-slate-700" />

          {/* Financial Settings Section */}
          <section>
            <h3 className="text-sm font-medium text-slate-900 dark:text-slate-200 flex items-center gap-2 mb-4 uppercase tracking-wider">
              <Landmark className="w-4 h-4 text-emerald-500" />
              Financial Defaults
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Default Currency</label>
                <select
                  name="currency"
                  value={localSettings.currency}
                  onChange={handleChange as any}
                  className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:text-white transition-colors"
                >
                  <option value="USD">USD ($)</option>
                  <option value="EUR">EUR (€)</option>
                  <option value="GBP">GBP (£)</option>
                  <option value="ETB">ETB (Br)</option>
                  <option value="AUD">AUD ($)</option>
                  <option value="CAD">CAD ($)</option>
                  <option value="JPY">JPY (¥)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Default Tax Rate (%)</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Percent className="h-4 w-4 text-slate-400" />
                  </div>
                  <input
                    type="number"
                    name="taxRate"
                    value={localSettings.taxRate}
                    onChange={handleChange}
                    min="0"
                    max="100"
                    step="0.01"
                    className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:text-white transition-colors"
                  />
                </div>
              </div>

            </div>
          </section>

          <hr className="border-slate-200 dark:border-slate-700" />

          {/* Terms & Conditions Section */}
          <section>
            <h3 className="text-sm font-medium text-slate-900 dark:text-slate-200 flex items-center gap-2 mb-4 uppercase tracking-wider">
              <FileText className="w-4 h-4 text-orange-500" />
              Default Terms & Conditions
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3 md:col-span-2">
                <div className="flex items-center justify-between">
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Payment Terms</label>
                  <button
                    type="button"
                    onClick={() => setLocalSettings(prev => ({ ...prev, paymentTermsList: [...(prev.paymentTermsList || []), ''] }))}
                    className="inline-flex items-center gap-1 text-xs font-medium text-indigo-600 hover:text-indigo-700 dark:text-indigo-400"
                  >
                    <Plus className="w-3 h-3" /> Add Term
                  </button>
                </div>
                {(localSettings.paymentTermsList || [localSettings.paymentTerms || '']).map((term, index) => (
                  <div key={index} className="flex gap-2">
                    <input
                      type="text"
                      value={term}
                      onChange={(e) => {
                        const newTerms = [...(localSettings.paymentTermsList || [localSettings.paymentTerms || ''])];
                        newTerms[index] = e.target.value;
                        setLocalSettings(prev => ({ ...prev, paymentTermsList: newTerms }));
                      }}
                      placeholder="e.g., 50% advance, 50% on delivery"
                      className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:text-white transition-colors"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const newTerms = [...(localSettings.paymentTermsList || [localSettings.paymentTerms || ''])];
                        newTerms.splice(index, 1);
                        setLocalSettings(prev => ({ ...prev, paymentTermsList: newTerms }));
                      }}
                      className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>

              <div className="space-y-1">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Default Validity (Days)</label>
                <input
                  type="text"
                  name="validityDays"
                  value={localSettings.validityDays || ''}
                  onChange={handleChange}
                  placeholder="e.g., 30"
                  className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:text-white transition-colors"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Default Delivery Terms</label>
                <input
                  type="text"
                  name="deliveryTerms"
                  value={localSettings.deliveryTerms || ''}
                  onChange={handleChange}
                  placeholder="e.g., Within 7-14 business days"
                  className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:text-white transition-colors"
                />
              </div>
            </div>
          </section>
        </fieldset>

        {isOwner && (
          <div className="px-6 py-4 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between">
            <div className="text-sm font-medium text-emerald-600 dark:text-emerald-400 transition-opacity duration-300" style={{ opacity: savedMessage ? 1 : 0 }}>
              Settings saved successfully.
            </div>
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 focus:ring-4 focus:ring-indigo-500/20 transition-all shadow-sm"
            >
              <Save className="w-4 h-4" />
              Save Settings
            </button>
          </div>
        )}
      </form>

      {isOwner && (
        <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
          <div className="p-6">
            <h3 className="text-sm font-medium text-slate-900 dark:text-slate-200 flex items-center gap-2 mb-1 uppercase tracking-wider">
              <Users className="w-4 h-4 text-blue-500" />
              Team & Roles
            </h3>
            <p className="text-sm text-slate-500 mb-4">Everyone on the team sees the same data; roles control who can edit what.</p>
            <div className="space-y-2">
              {team.map(member => (
                <div key={member.id} className="flex items-center justify-between gap-4 p-3 bg-slate-50 dark:bg-slate-900/50 rounded-lg border border-slate-100 dark:border-slate-700">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                      {member.fullName || member.email} {member.id === currentUserId && <span className="text-xs text-slate-400">(you)</span>}
                    </p>
                    <p className="text-xs text-slate-500 truncate">{member.email}</p>
                  </div>
                  <select
                    value={member.role}
                    onChange={(e) => onUpdateTeamRole?.(member.id, e.target.value as UserRole)}
                    disabled={member.id === currentUserId}
                    className="px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-700 dark:text-slate-300 disabled:opacity-50"
                    title={ROLE_DESCRIPTIONS[member.role]}
                  >
                    <option value="owner">Owner</option>
                    <option value="sales">Sales</option>
                    <option value="finance">Finance</option>
                    <option value="viewer">Viewer</option>
                  </select>
                </div>
              ))}
              {team.length === 0 && <p className="text-sm text-slate-400">No team members yet.</p>}
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2 text-xs text-slate-500">
              {(Object.entries(ROLE_DESCRIPTIONS) as [UserRole, string][]).map(([r, desc]) => (
                <p key={r}><strong className="text-slate-700 dark:text-slate-300 capitalize">{r}:</strong> {desc}</p>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
