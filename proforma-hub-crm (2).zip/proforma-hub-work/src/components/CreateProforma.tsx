import React, { useState, useEffect, useRef } from 'react';
import { v4 as uuidv4 } from 'uuid';
import html2pdf from 'html2pdf.js';
import { Save, Download, Printer, Plus, Trash2, Eye, EyeOff, Mail } from 'lucide-react';
import { CompanySettings, Proforma, LineItem, Client } from '../types';
import ProformaPreview from './ProformaPreview';
import { generateProformaNumber } from '../utils/formatters';

interface CreateProformaProps {
  settings: CompanySettings;
  proformas: Proforma[];
  onSave: (proforma: Proforma) => void;
  initialData?: Proforma | null;
  onClearInitialData?: () => void;
  prefillClient?: { clientId?: string | null; clientName: string; clientEmail: string; clientPhone: string; clientAddress: string };
  clients?: Client[];
}

const emptyItem: LineItem = { id: '', description: '', quantity: 1, unit: 'pcs', unitPrice: 0 };

export default function CreateProforma({ settings, proformas, onSave, initialData, onClearInitialData, prefillClient, clients = [] }: CreateProformaProps) {
  const printRef = useRef<HTMLDivElement>(null);
  const [showPreviewOnMobile, setShowPreviewOnMobile] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  
  const [proforma, setProforma] = useState<Proforma>(() => {
    if (initialData) return initialData;
    
    const today = new Date();
    const expiry = new Date();
    expiry.setDate(today.getDate() + 30);
    
    return {
      id: uuidv4(),
      clientId: prefillClient?.clientId || null,
      proformaNumber: generateProformaNumber(proformas),
      issueDate: today.toISOString().split('T')[0],
      expiryDate: expiry.toISOString().split('T')[0],
      clientName: prefillClient?.clientName || '',
      clientEmail: prefillClient?.clientEmail || '',
      clientPhone: prefillClient?.clientPhone || '',
      clientAddress: prefillClient?.clientAddress || '',
      items: [{ ...emptyItem, id: uuidv4() }],
      discountType: 'percentage',
      discountValue: 0,
      status: 'Draft',
      subtotal: 0,
      taxTotal: 0,
      discountTotal: 0,
      grandTotal: 0,
      includeStamp: false,
      paymentTermsList: settings.paymentTermsList || [settings.paymentTerms || ''],
      validityDays: settings.validityDays || '30',
      deliveryTerms: settings.deliveryTerms || '',
    };
  });

  // Calculate totals whenever items, discount, or tax changes
  useEffect(() => {
    let subtotal = 0;
    proforma.items.forEach(item => {
      subtotal += item.quantity * item.unitPrice;
    });

    let discountTotal = 0;
    if (proforma.discountType === 'percentage') {
      discountTotal = subtotal * (proforma.discountValue / 100);
    } else {
      discountTotal = proforma.discountValue;
    }

    const afterDiscount = subtotal - discountTotal;
    const taxTotal = Math.max(0, afterDiscount * (settings.taxRate / 100));
    const grandTotal = Math.max(0, afterDiscount + taxTotal);

    setProforma(prev => ({
      ...prev,
      subtotal,
      discountTotal,
      taxTotal,
      grandTotal,
    }));
  }, [proforma.items, proforma.discountType, proforma.discountValue, settings.taxRate]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setProforma(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) || 0 : value
    }));
  };

  const handleItemChange = (index: number, field: keyof LineItem, value: any) => {
    const newItems = [...proforma.items];
    newItems[index] = { ...newItems[index], [field]: value };
    setProforma(prev => ({ ...prev, items: newItems }));
  };

  const addItem = () => {
    setProforma(prev => ({
      ...prev,
      items: [...prev.items, { ...emptyItem, id: uuidv4() }]
    }));
  };

  const removeItem = (index: number) => {
    if (proforma.items.length <= 1) return;
    const newItems = [...proforma.items];
    newItems.splice(index, 1);
    setProforma(prev => ({ ...prev, items: newItems }));
  };

  const handleSave = () => {
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
    
    // Clear URL initial data if editing
    if (onClearInitialData) onClearInitialData();
    onSave(proforma);
  };

  const handleDownloadPDF = () => {
    if (!printRef.current) return;
    const element = printRef.current;
    
    const opt = {
      margin:       0.3,
      filename:     `${proforma.proformaNumber}.pdf`,
      image:        { type: 'jpeg', quality: 0.98 },
      html2canvas:  { scale: 2, useCORS: true },
      jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' },
      pagebreak:    { mode: ['css', 'legacy'] }
    };
    
    html2pdf().set(opt).from(element).save();
  };

  const handlePrint = () => {
    window.print();
  };

  const handleEmailToClient = () => {
    if (!proforma.clientEmail) {
      alert('Add a client email first.');
      return;
    }
    const subject = encodeURIComponent(`Proforma Invoice ${proforma.proformaNumber} — ${settings.companyName}`);
    const body = encodeURIComponent(
      `Dear ${proforma.clientName || 'Sir/Madam'},\n\n` +
      `Please find attached our Proforma Invoice ${proforma.proformaNumber}, valid for ${proforma.validityDays || settings.validityDays || '30'} days.\n\n` +
      `Total: ${new Intl.NumberFormat('en-US', { style: 'currency', currency: settings.currency }).format(proforma.grandTotal)}\n\n` +
      `Note: click "Export PDF" first and attach the downloaded file to this email — most email clients don't support attaching files automatically from a web link.\n\n` +
      `Best regards,\n${settings.companyName}`
    );
    window.location.href = `mailto:${proforma.clientEmail}?subject=${subject}&body=${body}`;
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 max-w-[1600px] mx-auto h-[calc(100vh-8rem)]">
      {/* Editor Panel */}
      <div className={`flex-1 flex flex-col bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 overflow-hidden ${showPreviewOnMobile ? 'hidden lg:flex' : 'flex'}`}>
        
        {/* Editor Toolbar */}
        <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
          <h2 className="font-semibold text-slate-800 dark:text-white flex items-center gap-2">
            {initialData ? 'Edit Proforma' : prefillClient ? 'New Proforma (from Lead)' : 'New Proforma'}
          </h2>
          <div className="flex gap-2">
            <button
              onClick={() => setShowPreviewOnMobile(true)}
              className="lg:hidden p-2 text-slate-600 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400"
              title="Show Preview"
            >
              <Eye className="w-5 h-5" />
            </button>
            <button
              onClick={handleSave}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 transition-colors"
            >
              <Save className="w-4 h-4" />
              <span className="hidden sm:inline">{saveSuccess ? 'Saved!' : 'Save Draft'}</span>
            </button>
            <button
              onClick={handleDownloadPDF}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-800 text-white text-sm font-medium rounded-lg hover:bg-slate-900 dark:bg-slate-700 dark:hover:bg-slate-600 transition-colors"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Export PDF</span>
            </button>
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:border dark:border-slate-600 text-sm font-medium rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={handleEmailToClient}
              title="Open a pre-filled email to the client"
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:border dark:border-slate-600 text-sm font-medium rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
            >
              <Mail className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Editor Form */}
        <div className="flex-1 overflow-y-auto p-6 space-y-8 custom-scrollbar">
          
          {/* Metadata */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Proforma No.</label>
              <input
                type="text"
                name="proformaNumber"
                value={proforma.proformaNumber}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white"
              />
            </div>
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Issue Date</label>
              <input
                type="date"
                name="issueDate"
                value={proforma.issueDate}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white"
              />
            </div>
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Valid Until</label>
              <input
                type="date"
                name="expiryDate"
                value={proforma.expiryDate}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <hr className="border-slate-200 dark:border-slate-700" />

          {/* Client Details */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-slate-800 dark:text-slate-200">Client Details</h3>
            {clients.length > 0 && (
              <div className="space-y-1">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Link to Existing Client (optional)</label>
                <select
                  value={proforma.clientId || ''}
                  onChange={(e) => {
                    const client = clients.find(c => c.id === e.target.value);
                    if (client) {
                      setProforma(prev => ({
                        ...prev,
                        clientId: client.id,
                        clientName: client.company ? `${client.name} (${client.company})` : client.name,
                        clientEmail: client.email,
                        clientPhone: client.phone,
                        clientAddress: client.address || '',
                      }));
                    } else {
                      setProforma(prev => ({ ...prev, clientId: null }));
                    }
                  }}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white text-sm"
                >
                  <option value="">— Type client details manually —</option>
                  {clients.map(c => <option key={c.id} value={c.id}>{c.name}{c.company ? ` (${c.company})` : ''}</option>)}
                </select>
              </div>
            )}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Client Name</label>
                <input
                  type="text"
                  name="clientName"
                  value={proforma.clientName}
                  onChange={handleChange}
                  placeholder="Client Business LLC"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Email</label>
                <input
                  type="email"
                  name="clientEmail"
                  value={proforma.clientEmail}
                  onChange={handleChange}
                  placeholder="contact@client.com"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Phone</label>
                <input
                  type="text"
                  name="clientPhone"
                  value={proforma.clientPhone}
                  onChange={handleChange}
                  placeholder="+1 (555) 987-6543"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white"
                />
              </div>
              <div className="space-y-1 md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Address</label>
                <textarea
                  name="clientAddress"
                  value={proforma.clientAddress}
                  onChange={handleChange}
                  rows={2}
                  placeholder="456 Client St, City, Country"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white resize-none"
                />
              </div>
            </div>
          </div>

          <hr className="border-slate-200 dark:border-slate-700" />

          {/* Line Items */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-800 dark:text-slate-200">Line Items</h3>
              <button
                type="button"
                onClick={addItem}
                className="inline-flex items-center gap-1 text-sm font-medium text-indigo-600 hover:text-indigo-700 dark:text-indigo-400 dark:hover:text-indigo-300"
              >
                <Plus className="w-4 h-4" /> Add Item
              </button>
            </div>
            
            <div className="space-y-3">
              {proforma.items.map((item, index) => (
                <div key={item.id} className="flex gap-3 items-start group">
                  <div className="flex-1 space-y-1">
                    <input
                      type="text"
                      value={item.description}
                      onChange={(e) => handleItemChange(index, 'description', e.target.value)}
                      placeholder="Item description"
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white text-sm"
                    />
                  </div>
                  <div className="w-20 space-y-1">
                    <input
                      type="number"
                      min="1"
                      value={item.quantity || ''}
                      onChange={(e) => handleItemChange(index, 'quantity', parseFloat(e.target.value) || 0)}
                      placeholder="Qty"
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white text-sm text-right"
                    />
                  </div>
                  <div className="w-20 space-y-1">
                    <input
                      type="text"
                      value={item.unit || ''}
                      onChange={(e) => handleItemChange(index, 'unit', e.target.value)}
                      placeholder="Unit"
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white text-sm text-center"
                    />
                  </div>
                  <div className="w-28 space-y-1">
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={item.unitPrice === 0 ? '' : item.unitPrice}
                      onChange={(e) => handleItemChange(index, 'unitPrice', parseFloat(e.target.value) || 0)}
                      placeholder="Price"
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white text-sm text-right"
                    />
                  </div>
                  <button
                    onClick={() => removeItem(index)}
                    disabled={proforma.items.length <= 1}
                    className="p-2 text-slate-400 hover:text-red-500 disabled:opacity-30 disabled:hover:text-slate-400 transition-colors mt-0.5"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <hr className="border-slate-200 dark:border-slate-700" />

          {/* Discount & Extras */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-slate-800 dark:text-slate-200">Options & Adjustments</h3>
            <div className="flex flex-wrap gap-8 items-start">
              <div className="space-y-1 w-48">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Discount</label>
                <div className="flex">
                  <select
                    name="discountType"
                    value={proforma.discountType}
                    onChange={handleChange as any}
                    className="px-2 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-l-lg border-r-0 focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white text-sm"
                  >
                    <option value="percentage">%</option>
                    <option value="fixed">Fixed</option>
                  </select>
                  <input
                    type="number"
                    name="discountValue"
                    min="0"
                    step={proforma.discountType === 'percentage' ? '1' : '0.01'}
                    value={proforma.discountValue || ''}
                    onChange={handleChange}
                    placeholder="0"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-r-lg focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white text-sm"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Company Stamp</label>
                <label className="flex items-center gap-3 cursor-pointer mt-2 pt-1">
                  <div className="relative">
                    <input
                      type="checkbox"
                      className="sr-only"
                      checked={proforma.includeStamp || false}
                      onChange={(e) => setProforma(prev => ({ ...prev, includeStamp: e.target.checked }))}
                    />
                    <div className={`block w-10 h-6 rounded-full transition-colors ${proforma.includeStamp ? 'bg-indigo-500' : 'bg-slate-300 dark:bg-slate-600'}`}></div>
                    <div className={`absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${proforma.includeStamp ? 'transform translate-x-4' : ''}`}></div>
                  </div>
                  <span className="text-sm text-slate-600 dark:text-slate-400">Include signature stamp on PDF</span>
                </label>
              </div>
            </div>
          </div>

          <hr className="border-slate-200 dark:border-slate-700" />

          {/* Terms & Conditions */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-slate-800 dark:text-slate-200">Terms & Conditions</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Payment Terms */}
              <div className="space-y-3 md:col-span-2">
                <div className="flex items-center justify-between">
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Payment Terms</label>
                  <button
                    type="button"
                    onClick={() => setProforma(prev => ({ ...prev, paymentTermsList: [...(prev.paymentTermsList || []), ''] }))}
                    className="inline-flex items-center gap-1 text-xs font-medium text-indigo-600 hover:text-indigo-700 dark:text-indigo-400"
                  >
                    <Plus className="w-3 h-3" /> Add Term
                  </button>
                </div>
                {(proforma.paymentTermsList || []).map((term, index) => (
                  <div key={index} className="flex gap-2">
                    <input
                      type="text"
                      value={term}
                      onChange={(e) => {
                        const newTerms = [...(proforma.paymentTermsList || [])];
                        newTerms[index] = e.target.value;
                        setProforma(prev => ({ ...prev, paymentTermsList: newTerms }));
                      }}
                      placeholder="e.g., 50% advance, 50% on delivery"
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white text-sm"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const newTerms = [...(proforma.paymentTermsList || [])];
                        newTerms.splice(index, 1);
                        setProforma(prev => ({ ...prev, paymentTermsList: newTerms }));
                      }}
                      className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>

              {/* Validity */}
              <div className="space-y-1">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Validity (Days)</label>
                <input
                  type="text"
                  name="validityDays"
                  value={proforma.validityDays || ''}
                  onChange={handleChange}
                  placeholder="e.g., 30"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white text-sm"
                />
              </div>

              {/* Delivery Terms */}
              <div className="space-y-1">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Delivery Terms</label>
                <input
                  type="text"
                  name="deliveryTerms"
                  value={proforma.deliveryTerms || ''}
                  onChange={handleChange}
                  placeholder="e.g., 14 days after advance payment"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white text-sm"
                />
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Preview Panel */}
      <div className={`flex-1 flex-col bg-slate-200 dark:bg-slate-900 rounded-xl overflow-hidden shadow-inner border border-slate-300 dark:border-slate-800 relative ${showPreviewOnMobile ? 'flex' : 'hidden lg:flex'}`}>
        <div className="absolute top-4 left-4 z-10 lg:hidden">
          <button
            onClick={() => setShowPreviewOnMobile(false)}
            className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 text-white rounded-lg shadow-lg text-sm font-medium hover:bg-slate-700 transition-colors"
          >
            <EyeOff className="w-4 h-4" /> Back to Editor
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-4 md:p-8 preview-scrollbar flex justify-center items-start">
          <div className="w-full max-w-4xl shadow-xl transition-all">
            <ProformaPreview proforma={proforma} settings={settings} printRef={printRef} />
          </div>
        </div>
      </div>
    </div>
  );
}
