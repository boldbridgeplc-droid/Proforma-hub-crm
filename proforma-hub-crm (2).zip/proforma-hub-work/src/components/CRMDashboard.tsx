import React from 'react';
import { Project, Expense, Invoice, Lead, LEAD_STAGES } from '../types';
import { Briefcase, DollarSign, Activity, CheckCircle, Target } from 'lucide-react';
import { formatCurrency } from '../utils/formatters';

interface DashboardProps {
  projects: Project[];
  expenses: Expense[];
  invoices: Invoice[];
  leads?: Lead[];
  currency?: string;
}

export default function CRMDashboard({ projects, expenses, invoices, leads = [], currency = 'USD' }: DashboardProps) {
  const activeProjects = projects.filter(p => p.status === 'In Progress' || p.status === 'On Hold').length;
  const completedProjects = projects.filter(p => p.status === 'Completed' || p.status === 'Closed').length;
  
  const totalContractValue = projects.reduce((sum, p) => sum + p.contractValue, 0);
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const netProfit = totalContractValue - totalExpenses;
  const profitMargin = totalContractValue > 0 ? (netProfit / totalContractValue) * 100 : 0;

  const totalInvoiced = invoices.reduce((sum, i) => sum + i.amount, 0);
  const totalCollected = invoices.filter(i => i.status === 'Paid').reduce((sum, i) => sum + i.amount, 0);

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold text-slate-800 dark:text-white">Overview Dashboard</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Active Projects */}
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400">Active Projects</h3>
            <div className="p-2 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg">
              <Briefcase className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-bold text-slate-900 dark:text-white">{activeProjects}</div>
          <p className="text-sm text-slate-500 mt-2">{completedProjects} projects completed</p>
        </div>

        {/* Total Contract Value */}
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400">Total Pipeline</h3>
            <div className="p-2 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-lg">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-bold text-slate-900 dark:text-white">${totalContractValue.toLocaleString()}</div>
          <p className="text-sm text-slate-500 mt-2">Total contract value</p>
        </div>

        {/* Total Expenses */}
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400">Total Expenses</h3>
            <div className="p-2 bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400 rounded-lg">
              <Activity className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-bold text-slate-900 dark:text-white">${totalExpenses.toLocaleString()}</div>
          <p className="text-sm text-slate-500 mt-2">Across all projects</p>
        </div>

        {/* Net Profit Margin */}
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400">Est. Profit Margin</h3>
            <div className="p-2 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg">
              <CheckCircle className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-bold text-slate-900 dark:text-white">{profitMargin.toFixed(1)}%</div>
          <p className="text-sm text-slate-500 mt-2">Est. Net: ${netProfit.toLocaleString()}</p>
        </div>
      </div>

      {leads.length > 0 && (
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 p-6">
          <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-4 flex items-center gap-2">
            <Target className="w-5 h-5 text-indigo-500" /> Leads Pipeline
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {LEAD_STAGES.map(stage => {
              const stageLeads = leads.filter(l => l.stage === stage);
              const value = stageLeads.reduce((sum, l) => sum + (l.estimatedValue || 0), 0);
              return (
                <div key={stage} className="p-3 bg-slate-50 dark:bg-slate-900/40 rounded-lg border border-slate-100 dark:border-slate-700">
                  <p className="text-xs text-slate-500 mb-1">{stage}</p>
                  <p className="text-xl font-bold text-slate-900 dark:text-white">{stageLeads.length}</p>
                  {value > 0 && <p className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1">{formatCurrency(value, currency)}</p>}
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 p-6">
          <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-4">Recent Projects</h3>
          <div className="space-y-4">
            {projects.slice(0, 5).map(project => (
              <div key={project.id} className="flex justify-between items-center p-3 hover:bg-slate-50 dark:hover:bg-slate-700/50 rounded-lg transition-colors border border-transparent hover:border-slate-200 dark:hover:border-slate-700">
                <div>
                  <p className="font-semibold text-slate-900 dark:text-white">{project.clientName}</p>
                  <p className="text-xs text-slate-500">WO: {project.workOrderNumber}</p>
                </div>
                <div className="text-right">
                  <p className="font-medium text-slate-900 dark:text-white">${project.contractValue.toLocaleString()}</p>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    project.status === 'In Progress' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' :
                    project.status === 'Completed' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' :
                    project.status === 'On Hold' ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400' :
                    'bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
                  }`}>
                    {project.status}
                  </span>
                </div>
              </div>
            ))}
            {projects.length === 0 && <p className="text-slate-500 text-sm text-center py-4">No active projects yet.</p>}
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 p-6">
          <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-4">Financial Health (Invoiced vs Collected)</h3>
          <div className="space-y-6">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-600 dark:text-slate-400">Total Invoiced</span>
                <span className="font-semibold text-slate-900 dark:text-white">${totalInvoiced.toLocaleString()}</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-700 rounded-full h-3">
                <div className="bg-blue-500 h-3 rounded-full" style={{ width: '100%' }}></div>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-600 dark:text-slate-400">Total Collected</span>
                <span className="font-semibold text-slate-900 dark:text-white">${totalCollected.toLocaleString()}</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-700 rounded-full h-3">
                <div className="bg-emerald-500 h-3 rounded-full" style={{ width: `${totalInvoiced > 0 ? (totalCollected / totalInvoiced) * 100 : 0}%` }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-600 dark:text-slate-400">Outstanding Balance</span>
                <span className="font-semibold text-orange-600 dark:text-orange-400">${(totalInvoiced - totalCollected).toLocaleString()}</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-700 rounded-full h-3">
                <div className="bg-orange-500 h-3 rounded-full" style={{ width: `${totalInvoiced > 0 ? ((totalInvoiced - totalCollected) / totalInvoiced) * 100 : 0}%` }}></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
