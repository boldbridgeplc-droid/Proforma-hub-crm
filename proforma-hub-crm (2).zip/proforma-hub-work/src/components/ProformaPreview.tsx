import React from 'react';
import { Proforma, CompanySettings } from '../types';
import { formatCurrency } from '../utils/formatters';

interface ProformaPreviewProps {
  proforma: Proforma;
  settings: CompanySettings;
  printRef?: React.RefObject<HTMLDivElement | null>;
}

export default function ProformaPreview({ proforma, settings, printRef }: ProformaPreviewProps) {
  return (
    <div 
      ref={printRef}
      className="bg-white text-slate-900 p-6 shadow-sm print:shadow-none print:p-0 max-w-4xl mx-auto rounded-xl print:rounded-none min-h-[1056px] font-sans"
    >
      <table className="w-full border-collapse">
        <thead className="print:table-header-group">
          <tr>
            <td className="pb-4">
              {/* Header Image */}
              {settings.headerImageUrl && (
                <div className="mb-6 border-b border-slate-100 pb-4">
                  <img src={settings.headerImageUrl} alt="Header" className="h-16 w-auto max-w-sm object-contain object-left" crossOrigin="anonymous" />
                </div>
              )}
              
              <header className="flex justify-between items-start">
                <div className="max-w-xs">
                  {!settings.headerImageUrl && settings.logoUrl ? (
                    <img src={settings.logoUrl} alt={settings.companyName} className="h-16 object-contain mb-4" crossOrigin="anonymous" />
                  ) : !settings.headerImageUrl ? (
                    <div className="h-16 flex items-center mb-4">
                      <h2 className="text-2xl font-bold text-slate-800">{settings.companyName}</h2>
                    </div>
                  ) : null}
                  <div className="text-sm text-slate-600 space-y-1 whitespace-pre-wrap">
                    {settings.companyName && !settings.logoUrl && null}
                    {settings.address && <p>{settings.address}</p>}
                    {settings.email && <p>{settings.email}</p>}
                    {settings.phone && <p>{settings.phone}</p>}
                  </div>
                </div>
                
                <div className="text-right">
                  <h1 className="text-3xl font-light text-slate-400 uppercase tracking-widest mb-4">Proforma</h1>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-end gap-4">
                      <span className="font-semibold text-slate-500">Invoice No:</span>
                      <span className="text-slate-800 font-medium">{proforma.proformaNumber}</span>
                    </div>
                    <div className="flex justify-end gap-4">
                      <span className="font-semibold text-slate-500">Date of Issue:</span>
                      <span className="text-slate-800">{proforma.issueDate || '-'}</span>
                    </div>
                    <div className="flex justify-end gap-4">
                      <span className="font-semibold text-slate-500">Valid Until:</span>
                      <span className="text-slate-800">{proforma.expiryDate || '-'}</span>
                    </div>
                  </div>
                </div>
              </header>
            </td>
          </tr>
        </thead>

        <tbody>
          <tr>
            <td>
              {/* Bill To */}
              <section className="mb-6 mt-2">
                <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-2 border-b border-slate-200 pb-1">Bill To</h3>
                <div className="text-sm text-slate-700 space-y-1">
                  <p className="font-bold text-slate-900 text-base">{proforma.clientName || 'Client Name'}</p>
                  {proforma.clientAddress && <p className="whitespace-pre-wrap">{proforma.clientAddress}</p>}
                  {proforma.clientEmail && <p>{proforma.clientEmail}</p>}
                  {proforma.clientPhone && <p>{proforma.clientPhone}</p>}
                </div>
              </section>

              {/* Line Items */}
              <section className="mb-6">
                <table className="w-full text-left text-sm border-collapse">
                  <thead>
                    <tr className="border-b-2 border-slate-800 text-slate-800">
                      <th className="py-2 font-semibold w-full">Description</th>
                      <th className="py-2 font-semibold text-right whitespace-nowrap px-4">Qty</th>
                      <th className="py-2 font-semibold text-center whitespace-nowrap px-4">Unit</th>
                      <th className="py-2 font-semibold text-right whitespace-nowrap px-4">Unit Price</th>
                      <th className="py-2 font-semibold text-right whitespace-nowrap pl-4">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 border-b border-slate-200">
                    {proforma.items.length === 0 && (
                      <tr>
                        <td colSpan={5} className="py-4 text-center text-slate-400 italic">No items added yet.</td>
                      </tr>
                    )}
                    {proforma.items.map((item, index) => (
                      <tr key={item.id || index} className="break-inside-avoid">
                        <td className="py-2 text-slate-800 font-medium">{item.description || 'Item description'}</td>
                        <td className="py-2 text-right text-slate-600 px-4">{item.quantity}</td>
                        <td className="py-2 text-center text-slate-600 px-4">{item.unit || '-'}</td>
                        <td className="py-2 text-right text-slate-600 px-4">{formatCurrency(item.unitPrice, settings.currency)}</td>
                        <td className="py-2 text-right text-slate-800 font-medium pl-4">{formatCurrency(item.quantity * item.unitPrice, settings.currency)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </section>

              {/* Totals */}
              <section className="flex justify-end mb-8 break-inside-avoid">
                <div className="w-full max-w-sm space-y-2 text-sm">
                  <div className="flex justify-between text-slate-600">
                    <span>Subtotal</span>
                    <span className="font-medium text-slate-800">{formatCurrency(proforma.subtotal, settings.currency)}</span>
                  </div>
                  
                  {proforma.discountTotal > 0 && (
                    <div className="flex justify-between text-emerald-600">
                      <span>Discount {proforma.discountType === 'percentage' && `(${proforma.discountValue}%)`}</span>
                      <span>-{formatCurrency(proforma.discountTotal, settings.currency)}</span>
                    </div>
                  )}

                  {proforma.taxTotal > 0 && (
                    <div className="flex justify-between text-slate-600">
                      <span>Tax ({settings.taxRate}%)</span>
                      <span className="font-medium text-slate-800">{formatCurrency(proforma.taxTotal, settings.currency)}</span>
                    </div>
                  )}

                  <div className="flex justify-between items-center border-t-2 border-slate-800 pt-2 mt-2">
                    <span className="font-bold text-slate-900 text-base">Grand Total</span>
                    <span className="font-bold text-slate-900 text-xl">{formatCurrency(proforma.grandTotal, settings.currency)}</span>
                  </div>
                </div>
              </section>

              {/* Signature & Stamp Area */}
              <section className="mb-6 flex justify-end break-inside-avoid relative z-10">
                <div className="w-64 relative text-center">
                  {proforma.includeStamp && settings.stampImageUrl && (
                    <div className="absolute bottom-2 left-1/2 -translate-x-1/2 opacity-90 mix-blend-multiply pointer-events-none flex items-center justify-center -z-10">
                      <img src={settings.stampImageUrl} alt="Stamp" className="max-w-[160px] max-h-[160px] object-contain" crossOrigin="anonymous" />
                    </div>
                  )}
                  <div className="border-b border-slate-400 h-16 mb-2 relative z-10"></div>
                  <p className="text-sm font-semibold text-slate-800 relative z-10">Authorized Signature</p>
                </div>
              </section>

              {/* Terms & Conditions */}
              <section className="mt-4 break-inside-avoid">
                <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Terms & Conditions</h3>
                <div className="text-xs text-slate-600 space-y-2">
                  {proforma.paymentTermsList && proforma.paymentTermsList.length > 0 && proforma.paymentTermsList.some(t => t.trim() !== '') && (
                    <div>
                      <span className="font-semibold text-slate-800">Payment: </span>
                      {proforma.paymentTermsList.length === 1 ? (
                        <span>{proforma.paymentTermsList[0]}</span>
                      ) : (
                        <ul className="list-disc pl-4 mt-1 space-y-0.5">
                          {proforma.paymentTermsList.filter(t => t.trim() !== '').map((term, i) => (
                            <li key={i}>{term}</li>
                          ))}
                        </ul>
                      )}
                    </div>
                  )}
                  {proforma.validityDays && (
                    <div>
                      <span className="font-semibold text-slate-800">Validity: </span>
                      <span>Valid for {proforma.validityDays} days from the date of issue.</span>
                    </div>
                  )}
                  {proforma.deliveryTerms && (
                    <div>
                      <span className="font-semibold text-slate-800">Delivery: </span>
                      <span>{proforma.deliveryTerms}</span>
                    </div>
                  )}
                  {(!proforma.paymentTermsList?.some(t => t.trim() !== '') && !proforma.validityDays && !proforma.deliveryTerms) && (
                    <p className="whitespace-pre-wrap">{settings.paymentTerms}</p>
                  )}
                </div>
              </section>
            </td>
          </tr>
        </tbody>

        <tfoot className="print:table-footer-group">
          <tr>
            <td className="pt-6">
              {/* Footer Images */}
              {(settings.footerImage1Url || settings.footerImage2Url) && (
                <div className="flex justify-center items-center gap-8 border-t border-slate-100 pt-4">
                  {settings.footerImage1Url && (
                    <img src={settings.footerImage1Url} alt="Footer 1" className="h-28 w-auto max-w-[48%] object-contain" crossOrigin="anonymous" />
                  )}
                  {settings.footerImage2Url && (
                    <img src={settings.footerImage2Url} alt="Footer 2" className="h-28 w-auto max-w-[48%] object-contain" crossOrigin="anonymous" />
                  )}
                </div>
              )}
            </td>
          </tr>
        </tfoot>
      </table>
    </div>
  );
}
