import React, { useState } from 'react';
import { Project, Expense, ProjectLog, Invoice, CompanySettings, Proforma } from '../types';
import { Briefcase, Receipt, FileText, ChevronLeft, Plus, DollarSign, Calendar, Target, CheckCircle, Package, Printer } from 'lucide-react';
import { formatCurrency } from '../utils/formatters';
import html2pdf from 'html2pdf.js';
import { createPortal } from 'react-dom';
import { WorkOrderTemplate, AcceptanceLetterTemplate, InvoiceTemplate } from './DocumentTemplates';

interface ProjectWorkspaceProps {
  project: Project;
  proforma: Proforma | undefined;
  expenses: Expense[];
  logs: ProjectLog[];
  invoices: Invoice[];
  settings: CompanySettings;
  onBack: () => void;
  onUpdateProject: (id: string, updates: Partial<Project>) => void;
  onAddExpense: (expense: Expense) => void;
  onAddLog: (log: ProjectLog) => void;
  onAddInvoice: (invoice: Invoice) => void;
  onUpdateInvoice?: (id: string, updates: Partial<Invoice>) => void;
  canWrite?: boolean;
}

export default function ProjectWorkspace({
  project, proforma, expenses, logs, invoices, settings, onBack, onUpdateProject, onAddExpense, onAddLog, onAddInvoice, onUpdateInvoice, canWrite = true
}: ProjectWorkspaceProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'expenses' | 'logs' | 'invoices'>('overview');
  const [printQueue, setPrintQueue] = useState<{ type: 'wo' | 'acceptance' | 'invoice', invoice?: Invoice } | null>(null);
  
  // Modals/Forms State
  const [showExpenseForm, setShowExpenseForm] = useState(false);
  const [newExpense, setNewExpense] = useState<Partial<Expense>>({ category: 'Materials', amount: 0, date: new Date().toISOString().split('T')[0] });
  
  const [newLog, setNewLog] = useState('');
  
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const totalInvoiced = invoices.reduce((sum, i) => sum + i.amount, 0);

  const handlePrint = (type: 'wo' | 'acceptance' | 'invoice', invoice?: Invoice) => {
    if (!proforma) return alert("Missing proforma data.");
    setPrintQueue({ type, invoice });
    
    setTimeout(() => {
      const element = document.getElementById('hidden-doc-preview');
      if (!element) return;
      
      const opt = {
        margin:       0.3,
        filename:     `${type}-${project.workOrderNumber}.pdf`,
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2, useCORS: true },
        jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
      };
      
      html2pdf().set(opt).from(element).save().then(() => {
        setPrintQueue(null);
      });
    }, 150);
  };

  const handleSaveExpense = () => {
    if (newExpense.amount && newExpense.description) {
      onAddExpense({
        id: crypto.randomUUID(),
        projectId: project.id,
        category: newExpense.category as Expense['category'],
        amount: Number(newExpense.amount),
        description: newExpense.description,
        receiptNumber: newExpense.receiptNumber || '',
        date: newExpense.date || new Date().toISOString().split('T')[0],
      });
      setShowExpenseForm(false);
      setNewExpense({ category: 'Materials', amount: 0, date: new Date().toISOString().split('T')[0] });
    }
  };

  const handleSaveLog = () => {
    if (newLog.trim()) {
      onAddLog({
        id: crypto.randomUUID(),
        projectId: project.id,
        note: newLog,
        date: new Date().toISOString()
      });
      setNewLog('');
    }
  };

  const generatePaymentRequest = () => {
    const amountStr = prompt('Enter payment request amount:', (project.contractValue - totalInvoiced).toString());
    if (amountStr && !isNaN(Number(amountStr))) {
      onAddInvoice({
        id: crypto.randomUUID(),
        projectId: project.id,
        type: 'Payment Request',
        invoiceNumber: `PR-${new Date().getFullYear()}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`,
        amount: Number(amountStr),
        status: 'Pending',
        date: new Date().toISOString().split('T')[0],
        notes: 'Progress payment request'
      });
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Hidden PDF Portal */}
      {printQueue && proforma && createPortal(
        <div id="hidden-doc-preview" className="fixed top-0 left-[-9999px] w-[800px] opacity-0 pointer-events-none">
          {printQueue.type === 'wo' && <WorkOrderTemplate project={project} proforma={proforma} settings={settings} />}
          {printQueue.type === 'acceptance' && <AcceptanceLetterTemplate project={project} proforma={proforma} settings={settings} />}
          {printQueue.type === 'invoice' && printQueue.invoice && <InvoiceTemplate invoice={printQueue.invoice} project={project} proforma={proforma} settings={settings} />}
        </div>,
        document.body
      )}

      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <button onClick={onBack} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors">
          <ChevronLeft className="w-5 h-5 text-slate-600 dark:text-slate-400" />
        </button>
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
            {project.clientName} 
            <span className={`text-xs px-2 py-1 rounded-full ${
              project.status === 'In Progress' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' :
              project.status === 'Completed' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' :
              project.status === 'On Hold' ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400' :
              'bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
            }`}>
              {project.status}
            </span>
          </h2>
          <p className="text-sm text-slate-500">WO: {project.workOrderNumber} | Started: {project.startDate}</p>
        </div>
        <div className="ml-auto">
          <select 
            value={project.status}
            onChange={(e) => onUpdateProject(project.id, { status: e.target.value as Project['status'] })}
            disabled={!canWrite}
            className="px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-700 dark:text-slate-300 shadow-sm disabled:opacity-60"
          >
            <option value="In Progress">In Progress</option>
            <option value="On Hold">On Hold</option>
            <option value="Completed">Completed</option>
            <option value="Closed">Closed</option>
          </select>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex space-x-1 bg-slate-100 dark:bg-slate-800/50 p-1 rounded-lg">
        {[
          { id: 'overview', label: 'Overview', icon: Target },
          { id: 'expenses', label: 'Expenses', icon: Receipt },
          { id: 'logs', label: 'Work Logs', icon: FileText },
          { id: 'invoices', label: 'Invoices', icon: DollarSign },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
              activeTab === tab.id 
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm' 
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-200/50 dark:hover:bg-slate-800'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <h3 className="text-sm font-medium text-slate-500 mb-1">Contract Value</h3>
              <p className="text-2xl font-bold text-slate-900 dark:text-white">{formatCurrency(project.contractValue, settings.currency)}</p>
            </div>
            <div className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <h3 className="text-sm font-medium text-slate-500 mb-1">Total Expenses</h3>
              <p className="text-2xl font-bold text-orange-600">{formatCurrency(totalExpenses, settings.currency)}</p>
            </div>
            <div className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <h3 className="text-sm font-medium text-slate-500 mb-1">Net Margin</h3>
              <p className="text-2xl font-bold text-emerald-600">{formatCurrency(project.contractValue - totalExpenses, settings.currency)}</p>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Internal Work Order</h3>
              <div className="flex gap-2">
                <button onClick={() => handlePrint('wo')} className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 rounded-md text-sm transition-colors">
                  <Printer className="w-4 h-4" /> Print WO
                </button>
                <button onClick={() => handlePrint('acceptance')} className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 rounded-md text-sm transition-colors">
                  <Printer className="w-4 h-4" /> Acceptance Letter
                </button>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-sm mb-6">
              <div>
                <span className="block text-slate-500">WO Number</span>
                <span className="font-medium dark:text-white">{project.workOrderNumber}</span>
              </div>
              <div>
                <span className="block text-slate-500">Assigned To</span>
                <input 
                  type="text" 
                  value={project.assignedTeam} 
                  onChange={(e) => onUpdateProject(project.id, { assignedTeam: e.target.value })}
                  className="bg-transparent border-b border-dashed border-slate-400 focus:border-indigo-500 focus:outline-none dark:text-white"
                />
              </div>
              <div>
                <span className="block text-slate-500">Start Date</span>
                <input 
                  type="date" 
                  value={project.startDate} 
                  onChange={(e) => onUpdateProject(project.id, { startDate: e.target.value })}
                  className="bg-transparent border-b border-dashed border-slate-400 focus:border-indigo-500 focus:outline-none dark:text-white"
                />
              </div>
              <div>
                <span className="block text-slate-500">Target Date</span>
                <input 
                  type="date" 
                  value={project.targetDate} 
                  onChange={(e) => onUpdateProject(project.id, { targetDate: e.target.value })}
                  className="bg-transparent border-b border-dashed border-slate-400 focus:border-indigo-500 focus:outline-none dark:text-white"
                />
              </div>
            </div>

            <div className="mt-6 border-t border-slate-200 dark:border-slate-700 pt-4">
              <h4 className="font-medium text-slate-800 dark:text-slate-200 mb-3">Scope of Work (From Proforma)</h4>
              <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-400 list-disc pl-5">
                {proforma?.items.map(item => (
                  <li key={item.id}>{item.quantity} {item.unit} - {item.description}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Expenses Tab */}
      {activeTab === 'expenses' && (
        <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Expense Tracker</h3>
            {canWrite && (
              <button 
                onClick={() => setShowExpenseForm(!showExpenseForm)}
                className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm transition-colors"
              >
                <Plus className="w-4 h-4" /> Add Expense
              </button>
            )}
          </div>

          {showExpenseForm && (
            <div className="mb-8 p-4 bg-slate-50 dark:bg-slate-900/50 rounded-lg border border-slate-200 dark:border-slate-700 grid grid-cols-1 md:grid-cols-5 gap-4 items-end">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Date</label>
                <input type="date" value={newExpense.date} onChange={e => setNewExpense({...newExpense, date: e.target.value})} className="w-full px-3 py-2 bg-white dark:bg-slate-800 border rounded-md dark:text-white dark:border-slate-600" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Category</label>
                <select value={newExpense.category} onChange={e => setNewExpense({...newExpense, category: e.target.value as any})} className="w-full px-3 py-2 bg-white dark:bg-slate-800 border rounded-md dark:text-white dark:border-slate-600">
                  <option>Materials</option><option>Labor</option><option>Transport</option><option>Misc</option>
                </select>
              </div>
              <div className="md:col-span-2">
                <label className="block text-xs font-medium text-slate-500 mb-1">Description</label>
                <input type="text" value={newExpense.description || ''} onChange={e => setNewExpense({...newExpense, description: e.target.value})} placeholder="What was purchased?" className="w-full px-3 py-2 bg-white dark:bg-slate-800 border rounded-md dark:text-white dark:border-slate-600" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Amount</label>
                <div className="flex gap-2">
                  <input type="number" value={newExpense.amount || ''} onChange={e => setNewExpense({...newExpense, amount: Number(e.target.value)})} className="w-full px-3 py-2 bg-white dark:bg-slate-800 border rounded-md dark:text-white dark:border-slate-600" />
                  <button onClick={handleSaveExpense} className="px-3 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700">Save</button>
                </div>
              </div>
            </div>
          )}

          <table className="w-full text-left text-sm whitespace-nowrap">
            <thead className="bg-slate-50 dark:bg-slate-900/50 text-slate-600 dark:text-slate-400">
              <tr>
                <th className="px-4 py-3 font-medium">Date</th>
                <th className="px-4 py-3 font-medium">Category</th>
                <th className="px-4 py-3 font-medium w-full">Description</th>
                <th className="px-4 py-3 font-medium text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700">
              {expenses.length === 0 ? <tr><td colSpan={4} className="text-center py-8 text-slate-500">No expenses recorded yet.</td></tr> : null}
              {expenses.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(exp => (
                <tr key={exp.id}>
                  <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{exp.date}</td>
                  <td className="px-4 py-3"><span className="px-2 py-1 bg-slate-100 dark:bg-slate-700 rounded text-xs">{exp.category}</span></td>
                  <td className="px-4 py-3 text-slate-900 dark:text-white">{exp.description}</td>
                  <td className="px-4 py-3 text-right font-medium text-slate-900 dark:text-white">{formatCurrency(exp.amount, settings.currency)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Logs Tab */}
      {activeTab === 'logs' && (
        <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm p-6">
          <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-6">Site Notes & Work Log</h3>
          
          {canWrite && (
            <div className="flex gap-2 mb-8">
              <textarea 
                value={newLog}
                onChange={e => setNewLog(e.target.value)}
                placeholder="Add a progress update, site note, or issue..."
                className="flex-1 px-4 py-3 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm dark:text-white resize-none h-20"
              />
              <button onClick={handleSaveLog} className="px-6 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium transition-colors">
                Post Note
              </button>
            </div>
          )}

          <div className="space-y-4">
            {logs.length === 0 && <p className="text-center text-slate-500 py-4">No notes added yet.</p>}
            {logs.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(log => (
              <div key={log.id} className="p-4 bg-slate-50 dark:bg-slate-700/30 rounded-lg border border-slate-100 dark:border-slate-700">
                <div className="flex items-center gap-2 mb-2 text-xs text-slate-500">
                  <Calendar className="w-3 h-3" />
                  {new Date(log.date).toLocaleString()}
                </div>
                <p className="text-sm text-slate-800 dark:text-slate-200 whitespace-pre-wrap">{log.note}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Invoices Tab */}
      {activeTab === 'invoices' && (
        <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Payment Requests & Invoices</h3>
            {canWrite && (
              <div className="flex gap-2">
                <button onClick={generatePaymentRequest} className="px-4 py-2 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 rounded-lg text-sm hover:bg-slate-50 dark:hover:bg-slate-600 transition-colors">
                  Generate Payment Request
                </button>
                <button 
                  onClick={() => {
                    if (confirm('Convert accepted proforma and payments into a Final Tax Invoice?')) {
                      onAddInvoice({
                        id: crypto.randomUUID(),
                        projectId: project.id,
                        type: 'Final Invoice',
                        invoiceNumber: `INV-${new Date().getFullYear()}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`,
                        amount: project.contractValue,
                        status: 'Pending',
                        date: new Date().toISOString().split('T')[0],
                        notes: 'Final Commercial Invoice'
                      });
                    }
                  }} 
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm transition-colors"
                >
                  Create Final Invoice
                </button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8 p-4 bg-slate-50 dark:bg-slate-900/50 rounded-lg border border-slate-200 dark:border-slate-700">
            <div>
              <p className="text-xs text-slate-500 mb-1">Contract Total</p>
              <p className="font-bold text-slate-900 dark:text-white">{formatCurrency(project.contractValue, settings.currency)}</p>
            </div>
            <div>
              <p className="text-xs text-slate-500 mb-1">Total Requested</p>
              <p className="font-bold text-blue-600">{formatCurrency(totalInvoiced, settings.currency)}</p>
            </div>
            <div>
              <p className="text-xs text-slate-500 mb-1">Remaining Balance</p>
              <p className="font-bold text-orange-600">{formatCurrency(project.contractValue - totalInvoiced, settings.currency)}</p>
            </div>
          </div>

          <div className="space-y-3">
            {invoices.length === 0 && <p className="text-center text-slate-500 py-4">No payment requests generated yet.</p>}
            {invoices.map(invoice => (
              <div key={invoice.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg gap-4">
                <div className="flex items-center gap-4">
                  <div className={`p-2 rounded-lg ${invoice.type === 'Final Invoice' ? 'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600' : 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600'}`}>
                    <Receipt className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-medium text-slate-900 dark:text-white">{invoice.invoiceNumber} <span className="text-slate-400 text-xs font-normal ml-2">{invoice.date}</span></p>
                    <p className="text-sm text-slate-500">{invoice.type}</p>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-4">
                  <div className="text-right">
                    <p className="font-bold text-slate-900 dark:text-white">{formatCurrency(invoice.amount, settings.currency)}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <select
                      value={invoice.status}
                      onChange={(e) => onUpdateInvoice && onUpdateInvoice(invoice.id, { status: e.target.value as any })}
                      disabled={!canWrite}
                      className={`text-xs px-2 py-1 rounded-full border-0 font-medium disabled:opacity-60 ${invoice.status === 'Paid' ? 'bg-emerald-100 text-emerald-700' : 'bg-orange-100 text-orange-700'}`}
                    >
                      <option value="Pending">Pending</option>
                      <option value="Paid">Paid</option>
                    </select>
                    <button onClick={() => handlePrint('invoice', invoice)} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-md text-slate-500 transition-colors tooltip" title="Print PDF">
                      <Printer className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
