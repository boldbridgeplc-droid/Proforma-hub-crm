export interface CompanySettings {
  companyName: string;
  address: string;
  email: string;
  phone: string;
  logoUrl: string;
  headerImageUrl?: string;
  footerImage1Url?: string;
  footerImage2Url?: string;
  stampImageUrl?: string;
  taxRate: number;
  currency: string;
  paymentTerms: string;
  paymentTermsList?: string[];
  validityDays?: string;
  deliveryTerms?: string;
}

export interface LineItem {
  id: string;
  description: string;
  quantity: number;
  unit?: string;
  unitPrice: number;
}

export interface Proforma {
  id: string;
  clientId?: string | null;
  proformaNumber: string;
  issueDate: string;
  expiryDate: string;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  clientAddress: string;
  items: LineItem[];
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  status: 'Draft' | 'Sent' | 'Accepted' | 'Rejected' | 'Converted';
  subtotal: number;
  taxTotal: number;
  discountTotal: number;
  grandTotal: number;
  includeStamp?: boolean;
  paymentTermsList?: string[];
  validityDays?: string;
  deliveryTerms?: string;
}

export interface Project {
  id: string;
  proformaId: string;
  clientId?: string | null;
  clientName: string;
  workOrderNumber: string;
  assignedTeam: string;
  startDate: string;
  targetDate: string;
  status: 'In Progress' | 'On Hold' | 'Completed' | 'Closed';
  contractValue: number;
  createdAt: string;
}

export interface Expense {
  id: string;
  projectId: string;
  category: 'Materials' | 'Labor' | 'Transport' | 'Misc';
  amount: number;
  description: string;
  receiptNumber: string;
  date: string;
}

export interface ProjectLog {
  id: string;
  projectId: string;
  note: string;
  date: string;
}

export interface Invoice {
  id: string;
  projectId: string;
  type: 'Payment Request' | 'Final Invoice';
  invoiceNumber: string;
  amount: number;
  status: 'Pending' | 'Paid';
  date: string;
  notes: string;
}

export type LeadStage = 'New' | 'Contacted' | 'Qualified' | 'Quoted' | 'Won' | 'Lost';

export const LEAD_STAGES: LeadStage[] = ['New', 'Contacted', 'Qualified', 'Quoted', 'Won', 'Lost'];

export interface Lead {
  id: string;
  clientId?: string | null;
  name: string;
  company?: string;
  email: string;
  phone: string;
  address?: string;
  source?: string;
  estimatedValue?: number;
  stage: LeadStage;
  createdAt: string;
  updatedAt: string;
  proformaId?: string;
  lostReason?: string;
}

export interface LeadActivity {
  id: string;
  leadId: string;
  note: string;
  date: string;
}

// ---------------------------------------------------------------------
// Multi-user / backend additions
// ---------------------------------------------------------------------

export type UserRole = 'owner' | 'sales' | 'finance' | 'viewer';

export interface Profile {
  id: string;
  fullName: string;
  email: string;
  role: UserRole;
  createdAt: string;
}

export interface Client {
  id: string;
  name: string;
  company?: string;
  email: string;
  phone: string;
  address?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export type TaskRelatedType = 'lead' | 'client' | 'project' | 'proforma' | 'invoice';

export interface Task {
  id: string;
  title: string;
  notes?: string;
  relatedType?: TaskRelatedType | null;
  relatedId?: string | null;
  dueDate?: string | null;
  completed: boolean;
  assignedTo?: string | null;
  createdBy?: string | null;
  createdAt: string;
}
