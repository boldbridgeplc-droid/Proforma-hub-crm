import React, { useState } from 'react';
import { Settings as SettingsIcon, FileText, History as HistoryIcon, Layout, Briefcase, BarChart2, Target, Users, CheckSquare, PieChart, LogOut, Loader2 } from 'lucide-react';
import Settings from './components/Settings';
import CreateProforma from './components/CreateProforma';
import History from './components/History';
import CRMDashboard from './components/CRMDashboard';
import ProjectWorkspace from './components/ProjectWorkspace';
import LeadsPipeline from './components/LeadsPipeline';
import Clients from './components/Clients';
import Tasks from './components/Tasks';
import Reports from './components/Reports';
import Login from './components/Login';
import SetupNeeded from './components/SetupNeeded';
import { isSupabaseConfigured } from './lib/supabase';
import { AuthProvider, useAuth } from './hooks/useAuth';
import { useSupabaseCRM } from './hooks/useSupabaseCRM';
import { Proforma, Project, Lead, Client, UserRole } from './types';

type Tab = 'dashboard' | 'leads' | 'clients' | 'create' | 'history' | 'projects' | 'tasks' | 'reports' | 'settings';

interface PrefillSource {
  clientId?: string | null;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  clientAddress: string;
  leadId?: string;
}

function AppShell() {
  const { user, profile, role, loading: authLoading, signOut } = useAuth();
  const crm = useSupabaseCRM(!!user);

  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [editingProforma, setEditingProforma] = useState<Proforma | null>(null);
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [prefillSource, setPrefillSource] = useState<PrefillSource | null>(null);

  const canWrite = role === 'owner' || role === 'sales';
  const canWriteFinance = role === 'owner' || role === 'finance';

  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex items-center justify-center">
        <Loader2 className="w-6 h-6 text-indigo-500 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  if (crm.loading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex items-center justify-center">
        <Loader2 className="w-6 h-6 text-indigo-500 animate-spin" />
      </div>
    );
  }

  const handleEdit = (proforma: Proforma) => {
    setEditingProforma(proforma);
    setPrefillSource(null);
    setActiveTab('create');
  };

  const handleClearEdit = () => setEditingProforma(null);

  const handleConvertToProject = (project: Project) => {
    crm.addProject(project);
    setActiveProjectId(project.id);
    setActiveTab('projects');
  };

  const handleConvertLeadToProforma = (lead: Lead) => {
    setEditingProforma(null);
    setPrefillSource({
      clientId: lead.clientId,
      clientName: lead.name + (lead.company ? ` (${lead.company})` : ''),
      clientEmail: lead.email,
      clientPhone: lead.phone,
      clientAddress: lead.address || '',
      leadId: lead.id,
    });
    setActiveTab('create');
  };

  const handleCreateProformaForClient = (client: Client) => {
    setEditingProforma(null);
    setPrefillSource({
      clientId: client.id,
      clientName: client.company ? `${client.name} (${client.company})` : client.name,
      clientEmail: client.email,
      clientPhone: client.phone,
      clientAddress: client.address || '',
    });
    setActiveTab('create');
  };

  const handleSaveProforma = async (proforma: Proforma) => {
    const saved = await crm.saveProforma(proforma);
    if (prefillSource?.leadId) {
      const lead = crm.leads.find(l => l.id === prefillSource.leadId);
      if (lead) {
        crm.updateLead(lead.id, {
          stage: lead.stage === 'New' || lead.stage === 'Contacted' ? 'Quoted' : lead.stage,
          proformaId: saved.id,
        });
      }
    }
    setPrefillSource(null);
  };

  const navItem = (tab: Tab, label: string, Icon: any, visible = true) => visible && (
    <button
      onClick={() => { setActiveTab(tab); setActiveProjectId(null); if (tab === 'create') { handleClearEdit(); setPrefillSource(null); } }}
      className={`px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center gap-2 whitespace-nowrap ${
        activeTab === tab
          ? 'bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-400'
          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 dark:text-slate-400 dark:hover:text-white dark:hover:bg-slate-800'
      }`}
    >
      <Icon className="w-4 h-4" />
      <span>{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 font-sans print:bg-white flex flex-col">
      <header className="bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 sticky top-0 z-40 print:hidden overflow-x-auto">
        <div className="max-w-[1600px] mx-auto px-4 h-16 flex items-center justify-between min-w-[900px]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center shadow-sm">
              <Layout className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-indigo-500 dark:from-indigo-400 dark:to-indigo-300">
              Proforma CRM
            </h1>
          </div>

          <nav className="flex items-center gap-1">
            {navItem('dashboard', 'Dashboard', BarChart2)}
            {navItem('leads', 'Leads', Target)}
            {navItem('clients', 'Clients', Users)}
            {navItem('create', 'Proforma', FileText)}
            {navItem('history', 'History', HistoryIcon)}
            {navItem('projects', 'Projects', Briefcase)}
            {navItem('tasks', 'Tasks', CheckSquare)}
            {navItem('reports', 'Reports', PieChart)}
            {navItem('settings', 'Settings', SettingsIcon)}
          </nav>

          <div className="flex items-center gap-3 pl-3">
            <div className="text-right hidden lg:block">
              <p className="text-xs font-medium text-slate-700 dark:text-slate-300 leading-tight">{profile?.fullName || profile?.email}</p>
              <p className="text-[10px] text-slate-400 capitalize leading-tight">{role}</p>
            </div>
            <button onClick={signOut} title="Sign out" className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 rounded-lg transition-colors">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 p-4 md:p-6 lg:p-8 print:p-0 w-full max-w-[1600px] mx-auto">
        {activeTab === 'dashboard' && (
          <CRMDashboard
            projects={crm.projects}
            expenses={crm.expenses}
            invoices={crm.invoices}
            leads={crm.leads}
            currency={crm.settings.currency}
          />
        )}
        {activeTab === 'leads' && (
          <LeadsPipeline
            leads={crm.leads}
            leadActivities={crm.leadActivities}
            settings={crm.settings}
            onAddLead={crm.addLead}
            onUpdateLead={crm.updateLead}
            onDeleteLead={crm.deleteLead}
            onAddActivity={crm.addLeadActivity}
            onConvertToProforma={handleConvertLeadToProforma}
            canWrite={canWrite}
          />
        )}
        {activeTab === 'clients' && (
          <Clients
            clients={crm.clients}
            leads={crm.leads}
            proformas={crm.proformas}
            projects={crm.projects}
            settings={crm.settings}
            role={role}
            onAddClient={crm.addClient}
            onUpdateClient={crm.updateClient}
            onDeleteClient={crm.deleteClient}
            onCreateProformaForClient={handleCreateProformaForClient}
          />
        )}
        {activeTab === 'create' && (
          <CreateProforma
            key={editingProforma ? `edit-${editingProforma.id}` : prefillSource ? `prefill-${prefillSource.clientId || prefillSource.leadId}` : 'new'}
            settings={crm.settings}
            proformas={crm.proformas}
            onSave={handleSaveProforma}
            initialData={editingProforma}
            onClearInitialData={handleClearEdit}
            prefillClient={prefillSource || undefined}
            clients={crm.clients}
          />
        )}
        {activeTab === 'history' && (
          <History
            proformas={crm.proformas}
            onUpdateProforma={crm.saveProforma}
            onDeleteProforma={crm.deleteProforma}
            onEdit={handleEdit}
            settings={crm.settings}
            onConvertToProject={handleConvertToProject}
            canWrite={canWrite}
          />
        )}
        {activeTab === 'projects' && (
          activeProjectId ? (
            <ProjectWorkspace
              project={crm.projects.find(p => p.id === activeProjectId)!}
              proforma={crm.proformas.find(p => p.id === crm.projects.find(proj => proj.id === activeProjectId)?.proformaId)}
              expenses={crm.expenses.filter(e => e.projectId === activeProjectId)}
              logs={crm.projectLogs.filter(l => l.projectId === activeProjectId)}
              invoices={crm.invoices.filter(i => i.projectId === activeProjectId)}
              settings={crm.settings}
              onBack={() => setActiveProjectId(null)}
              onUpdateProject={crm.updateProject}
              onAddExpense={crm.addExpense}
              onAddLog={crm.addLog}
              onAddInvoice={crm.addInvoice}
              onUpdateInvoice={crm.updateInvoice}
              canWrite={canWriteFinance}
            />
          ) : (
            <div className="max-w-6xl mx-auto space-y-6">
              <h2 className="text-2xl font-bold text-slate-800 dark:text-white">Active Projects</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {crm.projects.length === 0 && <p className="text-slate-500 col-span-full">No active projects found. Go to History to convert an accepted Proforma into a project.</p>}
                {crm.projects.map(project => (
                  <div
                    key={project.id}
                    onClick={() => setActiveProjectId(project.id)}
                    className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 p-6 cursor-pointer hover:border-indigo-500 dark:hover:border-indigo-400 transition-colors group"
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div className="p-2 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 rounded-lg group-hover:bg-indigo-100 transition-colors">
                        <Briefcase className="w-5 h-5" />
                      </div>
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        project.status === 'In Progress' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' :
                        project.status === 'Completed' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' :
                        project.status === 'On Hold' ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400' :
                        'bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
                      }`}>
                        {project.status}
                      </span>
                    </div>
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">{project.clientName}</h3>
                    <p className="text-sm text-slate-500 mb-4">{project.workOrderNumber}</p>

                    <div className="pt-4 border-t border-slate-100 dark:border-slate-700 flex justify-between items-center text-sm">
                      <span className="text-slate-500">Contract Value</span>
                      <span className="font-semibold text-slate-900 dark:text-white">
                        {new Intl.NumberFormat('en-US', { style: 'currency', currency: crm.settings.currency }).format(project.contractValue)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )
        )}
        {activeTab === 'tasks' && (
          <Tasks
            tasks={crm.tasks}
            clients={crm.clients}
            leads={crm.leads}
            projects={crm.projects}
            onAddTask={crm.addTask}
            onUpdateTask={crm.updateTask}
            onDeleteTask={crm.deleteTask}
            canWrite={role !== 'viewer'}
          />
        )}
        {activeTab === 'reports' && (
          <Reports leads={crm.leads} proformas={crm.proformas} invoices={crm.invoices} settings={crm.settings} />
        )}
        {activeTab === 'settings' && (
          <Settings
            settings={crm.settings}
            setSettings={(s) => crm.updateSettings(s)}
            role={role}
            currentUserId={user.id}
            team={crm.team}
            onUpdateTeamRole={crm.updateTeamRole}
          />
        )}
      </main>
    </div>
  );
}

export default function App() {
  if (!isSupabaseConfigured) {
    return <SetupNeeded />;
  }
  return (
    <AuthProvider>
      <AppShell />
    </AuthProvider>
  );
}
