import { CompanySettings } from '../types';

export const DEFAULT_SETTINGS: CompanySettings = {
  companyName: 'Acme Corporation',
  address: '123 Business Rd.\nTech City, TC 10100',
  email: 'billing@acmecorp.com',
  phone: '+1 (555) 123-4567',
  logoUrl: '',
  headerImageUrl: '',
  footerImage1Url: '',
  footerImage2Url: '',
  stampImageUrl: '',
  taxRate: 10,
  currency: 'USD',
  paymentTerms: 'This is a proforma invoice. Valid for 30 days from the date of issue. Full payment is required before delivery of goods/services.',
  paymentTermsList: ['100% advance payment required'],
  validityDays: '30',
  deliveryTerms: 'Within 7-14 business days after payment confirmation'
};
